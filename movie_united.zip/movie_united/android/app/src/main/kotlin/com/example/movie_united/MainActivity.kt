package com.example.movie_united

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
