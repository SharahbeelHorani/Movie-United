import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFFc31c24);
const kDarkBlackColor = Color(0xFF191919);
const kFullBlack = Colors.black;
const kBgColor = Color(0xFFE7E7E7);
const kBodyTextColor = Color(0xFF666666);

const kDefaultPadding = 20.0;
const kMaxWidth = 1232.0; // 1232.0 
const kDefaultDuration = Duration(milliseconds: 250);