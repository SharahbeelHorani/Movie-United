import 'package:flutter/material.dart';
import 'package:custom_switch/custom_switch.dart';
import 'package:movie_united/model/language.dart';

import '../main.dart';
import 'language_constants.dart';

class SwitchLanguage extends StatefulWidget {
  SwitchLanguage({Key key}) : super(key: key);

  @override
  _SwitchLanguageState createState() => _SwitchLanguageState();
}

class _SwitchLanguageState extends State<SwitchLanguage> {
  void _changeLanguage(Language language) async {
    Locale _locale = await setLocale(language.languageCode);
    MyApp.setLocale(context, _locale);
  }

  bool isSwitched = false;
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        CustomSwitch(
          value: isSwitched,
          activeColor: Color(0xFFc31c24),
          onChanged: (value) {
             var index = 0;
              if (!isSwitched) {
               index = 1;
                setState(() {
              isSwitched = value;
              _changeLanguage(Language(index, "ar"));
            });
              }else if(isSwitched){
                  setState(() {
              isSwitched = value;
              _changeLanguage(Language(index, "en"));
            });
              }else{
                    setState(() {
              isSwitched = value;
              _changeLanguage(Language(index, "ar"));
            });
              }
            
          },
        )
        
      ],
    );
  }
}

