import 'package:flutter/material.dart';
import 'package:movie_united/main.dart';
import 'package:movie_united/pages/lang.dart';
import 'package:movie_united/pages/movies.dart';
import 'package:movie_united/pages/home.dart';
import 'package:movie_united/pages/preview.dart';
import 'package:movie_united/pages/profile.dart';
import 'package:movie_united/pages/rating.dart';
import 'package:movie_united/pages/topmovies.dart';
import 'package:movie_united/pages/toptvseries.dart';
import 'package:movie_united/pages/tvPreview.dart';
import 'package:movie_united/pages/tvseries.dart';
import 'package:movie_united/pages/wishlist.dart';
import 'package:movie_united/routes/route_names.dart';

class RouteGenerator {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case HomeRoute:
        return MaterialPageRoute(builder: (_) => Home());
        break;
      case MoviesRoute:
        return MaterialPageRoute(builder: (_) => Movies());
        break;
      case TvRoute:
        return MaterialPageRoute(builder: (_) => TvSeries());
        break;
        case settingsRoute:
        return MaterialPageRoute(builder: (_) => SettingsPage());
      case TopMoviesRoute:
        return MaterialPageRoute(builder: (_) => TopMovies());
        break;
      case PreviewRoute:
        if(settings.arguments is String)
        {
          return MaterialPageRoute(builder: (_) => Preview(movId: settings.arguments.toString()));
        }
        else{
          return MaterialPageRoute(builder: (_) => TopMovies());
        }
        break;
      case TvPreviewRoute:
        if(settings.arguments is String)
        {
          return MaterialPageRoute(builder: (_) => TvPreview(tvId: settings.arguments.toString()));
        }
        else{
          return MaterialPageRoute(builder: (_) => TopMovies());
        }
        break;
      case TopTvRoute:
        return MaterialPageRoute(builder: (_) => TopTvSeries());
        break;
      case ProfileRoute:
        return MaterialPageRoute(builder: (_) => Profile());
        break;
      case WishlistRoute:
        return MaterialPageRoute(builder: (_) => Wishlist());
        break;
      case RatingRoute:
        return MaterialPageRoute(builder: (_) => Rating());
        break;
      default:
        return MaterialPageRoute(builder: (_) => Home());
    }
  }
}