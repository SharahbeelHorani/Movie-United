import 'package:flutter/material.dart';

const String HomeRoute = '/HomePage';
const String MoviesRoute = '/MoviesPage';
const String TvRoute = '/TvPage';
const String TopMoviesRoute = '/TopMoviesPage';
const String TopTvRoute = '/TopTvPage';
const String PreviewRoute = '/preview';
const String TvPreviewRoute = '/tvpreview';
const String ProfileRoute = '/profile';
const String WishlistRoute = '/wishlist';
const String RatingRoute = '/ratings';
const String settingsRoute = "settings";




final navKey = new GlobalKey<NavigatorState>();
