import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:movie_united/localization/switch_lan.dart';
import 'package:movie_united/pages/home.dart';
import 'package:movie_united/pages/login.dart';
import 'package:movie_united/routes/route_names.dart';
import 'package:movie_united/routes/router_generator.dart';
import 'package:firebase_core/firebase_core.dart';

import 'localization/demo_localization.dart';
import 'localization/language_constants.dart';
import 'model/language.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MaterialApp(
    color: kFullBlack,
    debugShowCheckedModeBanner: false,
    title: 'Navigation Basics',
    home: MyApp(),
  ));
}

final MyDrawer _drawer = new MyDrawer();
final MyEndDrawer _endDrawer = new MyEndDrawer();

class MyEndDrawer extends StatefulWidget {
  const MyEndDrawer({Key key}) : super(key: key);

  @override
  _MyEndDrawerState createState() => _MyEndDrawerState();
}

class _MyEndDrawerState extends State<MyEndDrawer> {
  final FirebaseAuth auth = FirebaseAuth.instance;

  inputData() {
    String uid = "";
    final User user = auth.currentUser;
    if (user != null) {
      return (uid = user.displayName);
    } else
      return (uid = "No");
  }

  bool isLogged = false;
  String userEmail;
  String displayName;
  signOut() async {
    await FirebaseAuth.instance.signOut();
    setState(() {
      isLogged = false;
      userEmail = '';
    });
  }

  @override
  Widget build(BuildContext contexts) {
    return new Drawer(
      child: Container(
        color: kDarkBlackColor,
        child: StreamBuilder(
            stream: FirebaseAuth.instance.authStateChanges(),
            builder: (BuildContext context, snapshot) {
              if (snapshot.hasData && inputData() != 'No') {
                isLogged = true;
                return (ListView(
                  children: <Widget>[
                    new DrawerHeader(
                      child: Center(
                        child: CircleAvatar(
                            radius: 65,
                            backgroundColor: kBodyTextColor,
                            child: Icon(
                              Icons.person_rounded,
                              color: kPrimaryColor,
                              size: 100,
                            )),
                      ),
                    ),
                    Divider(),
                    Center(
                        child: new Text(
                      inputData().toString().toUpperCase(),
                      style: TextStyle(color: Colors.white),
                    )),
                    Divider(),
                    new ListTile(
                      leading: new Icon(
                        Icons.person,
                        color: kPrimaryColor,
                      ),
                      title: new Text(
                        getTranslated(context, "profile"),
                        style: TextStyle(color: Colors.white),
                      ),
                      onTap: () {
                        Navigator.of(context)..pop();
                        navKey.currentState.pushNamed(ProfileRoute);
                      },
                    ),
                    new ListTile(
                      leading: new Icon(
                        Icons.list,
                        color: kPrimaryColor,
                      ),
                      title: new Text(
                        getTranslated(context, "wishlist"),
                        style: TextStyle(color: Colors.white),
                      ),
                      onTap: () {
                        Navigator.of(context)..pop();
                        navKey.currentState.pushNamed(WishlistRoute);
                      },
                    ),
                    new ListTile(
                      leading: new Icon(
                        Icons.star,
                        color: kPrimaryColor,
                      ),
                      title: new Text(
                        getTranslated(context, "my_rating"),
                        style: TextStyle(color: Colors.white),
                      ),
                      onTap: () {
                        Navigator.of(context)..pop();
                        navKey.currentState.pushNamed(RatingRoute);
                      },
                    ),
                    new ListTile(
                      leading: new Icon(
                        Icons.logout,
                        color: kPrimaryColor,
                      ),
                      title: new Text(
                        getTranslated(context, "sign_out"),
                        style: TextStyle(color: Colors.white),
                      ),
                      onTap: () {
                        signOut();
                      },
                    ),
                  ],
                ));
              } else if (inputData() != 'No') {
                isLogged = true;
                return (ListView(
                  children: <Widget>[
                    new DrawerHeader(
                      child: Center(
                        child: CircleAvatar(
                            radius: 65,
                            backgroundColor: kBodyTextColor,
                            child: Icon(
                              Icons.person_rounded,
                              color: kPrimaryColor,
                              size: 100,
                            )),
                      ),
                    ),
                    Divider(),
                    Center(
                        child: new Text(
                      inputData().toString().toUpperCase(),
                      style: TextStyle(color: Colors.white),
                    )),
                    Divider(),
                    new ListTile(
                      leading: new Icon(
                        Icons.person,
                        color: kPrimaryColor,
                      ),
                      title: new Text(
                        getTranslated(context, "profile"),
                        style: TextStyle(color: Colors.white),
                      ),
                      onTap: () {
                        Navigator.of(context)..pop();
                        navKey.currentState.pushNamed(ProfileRoute);
                      },
                    ),
                    new ListTile(
                      leading: new Icon(
                        Icons.list,
                        color: kPrimaryColor,
                      ),
                      title: new Text(
                        getTranslated(context, "wishlist"),
                        style: TextStyle(color: Colors.white),
                      ),
                      onTap: () {
                        Navigator.of(context)..pop();
                        navKey.currentState.pushNamed(WishlistRoute);
                      },
                    ),
                    new ListTile(
                      leading: new Icon(
                        Icons.star,
                        color: kPrimaryColor,
                      ),
                      title: new Text(
                        getTranslated(context, "my_rating"),
                        style: TextStyle(color: Colors.white),
                      ),
                      onTap: () {
                        Navigator.of(context)..pop();
                        navKey.currentState.pushNamed(RatingRoute);
                      },
                    ),
                    new ListTile(
                      leading: new Icon(
                        Icons.logout,
                        color: kPrimaryColor,
                      ),
                      title: new Text(
                        getTranslated(context, "sign_out"),
                        style: TextStyle(color: Colors.white),
                      ),
                      onTap: () {
                        signOut();
                      },
                    ),
                  ],
                ));
              } else if (inputData() == 'No') {
                isLogged = false;
                return (ListView(
                  children: <Widget>[
                    new DrawerHeader(
                      child: Center(
                        child: CircleAvatar(
                            radius: 65,
                            backgroundColor: kBodyTextColor,
                            child: Icon(
                              Icons.person_rounded,
                              color: kPrimaryColor,
                              size: 100,
                            )),
                      ),
                    ),
                    Divider(),
                    Center(
                        child: new Text(
                      getTranslated(context, "you_are_not_logged_in"),
                      style: TextStyle(color: Colors.white),
                    )),
                    SizedBox(height: 20),
                    Center(
                        child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Login(bcx: contexts)),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        primary: kPrimaryColor,
                        padding: EdgeInsets.symmetric(
                          horizontal: kDefaultPadding * 1.5,
                          vertical: kDefaultPadding,
                        ),
                      ),
                      child: Text(getTranslated(context, "sign_in")),
                    )),
                  ],
                ));
              } else if (!snapshot.hasData && inputData() == 'No') {
                isLogged = false;
                return (ListView(
                  children: <Widget>[
                    new DrawerHeader(
                      child: Center(
                        child: CircleAvatar(
                            radius: 65,
                            backgroundColor: kBodyTextColor,
                            child: Icon(
                              Icons.person_rounded,
                              color: kPrimaryColor,
                              size: 100,
                            )),
                      ),
                    ),
                    Divider(),
                    Center(
                        child: new Text(
                      getTranslated(context, "you_are_not_logged_in"),
                      style: TextStyle(color: Colors.white),
                    )),
                    SizedBox(height: 20),
                    Center(
                        child: ElevatedButton(
                      onPressed: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Login(bcx: contexts)),
                        );
                      },
                      style: ElevatedButton.styleFrom(
                        primary: kPrimaryColor,
                        padding: EdgeInsets.symmetric(
                          horizontal: kDefaultPadding * 1.5,
                          vertical: kDefaultPadding,
                        ),
                      ),
                      child: Text(getTranslated(context, "sign_in")),
                    )),
                  ],
                ));
              } else
                return (Container());
              //logCheck();
            }),
      ),
    );
  }
}

class MyDrawer extends StatefulWidget {
  const MyDrawer({Key key}) : super(key: key);

  @override
  _MyDrawerState createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  void _changeLanguage(Language language) async {
    Locale _locale = await setLocale(language.languageCode);
    MyApp.setLocale(context, _locale);
  }

  int _toggleValue = 0;
  @override
  Widget build(BuildContext context) {
    return new Drawer(
      child: Container(
        color: kDarkBlackColor,
        child: ListView(
          children: <Widget>[
            new DrawerHeader(
              child: Center(
                child: Image.asset('assets/images/Logo.png'),
              ),
            ),
            new ListTile(
              leading: new Icon(
                Icons.home,
                color: kPrimaryColor,
              ),
              title: new Text(
                getTranslated(context, "home"),
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.of(context)..pop();
                navKey.currentState.pushNamed(HomeRoute);
              },
            ),
            new ListTile(
              leading: new Icon(
                Icons.movie,
                color: kPrimaryColor,
              ),
              title: new Text(
                getTranslated(context, "movies"),
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.of(context)..pop();
                navKey.currentState.pushNamed(MoviesRoute);
              },
            ),
            new ListTile(
              leading: new Icon(
                Icons.tv,
                color: kPrimaryColor,
              ),
              title: new Text(
                getTranslated(context, "tv_series"),
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.of(context)..pop();
                navKey.currentState.pushNamed(TvRoute);
              },
            ),
            new ListTile(
              leading: new Icon(
                Icons.stars,
                color: kPrimaryColor,
              ),
              title: new Text(
                getTranslated(context, "top_movies"),
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.of(context)..pop();
                navKey.currentState.pushNamed(TopMoviesRoute);
              },
            ),
            new ListTile(
              leading: new Icon(
                Icons.stars,
                color: kPrimaryColor,
              ),
              title: new Text(
                getTranslated(context, "top_tv_series"),
                style: TextStyle(color: Colors.white),
              ),
              onTap: () {
                Navigator.of(context)..pop();
                navKey.currentState.pushNamed(TopTvRoute);
              },
            ),
            Divider(
              height: 90,
              thickness: 0.45,
              color: kPrimaryColor,
            ),
            Container(
              child: Row(
               mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                //crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Icon(
                    Icons.language,
                    color: kPrimaryColor,
                  ),
                  Text(
                    getTranslated(context, "change_language"),
                    style: TextStyle(color: Colors.white, fontSize: 17),
                  ),
                  SwitchLanguage(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class MyApp extends StatefulWidget {
  // This widget is the root of your application.
  static void setLocale(BuildContext context, Locale newLocale) {
    _MyAppState state = context.findAncestorStateOfType<_MyAppState>();
    state.setLocale(newLocale);
  }

  @override
  _MyAppState createState() => _MyAppState();
}

class _MyAppState extends State<MyApp> {
  final GlobalKey<ScaffoldState> _scaffoldkey = new GlobalKey();
  Locale _locale;
  setLocale(Locale locale) {
    setState(() {
      _locale = locale;
    });
  }

  @override
  void didChangeDependencies() {
    getLocale().then((locale) {
      setState(() {
        this._locale = locale;
      });
    });
    super.didChangeDependencies();
  }

  @override
  Widget build(BuildContext context) {
    if (this._locale == null) {
      return Container(
        child: Center(
          child: CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.blue[800])),
        ),
      );
    } else {
      return MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Movie United',
        builder: (context, child) {
          return MediaQuery(
            data: MediaQuery.of(context).copyWith(textScaleFactor: 1.0),
            child: Scaffold(
              backgroundColor: kFullBlack,
              extendBodyBehindAppBar: true,
              key: _scaffoldkey,
              appBar: AppBar(
                backgroundColor: kDarkBlackColor.withOpacity(0.7),
                elevation: 0,
                title: Image.asset(
                  'assets/images/Logo.png',
                  height: MediaQuery.of(context).size.height / 22,
                ),
                actions: [
                  IconButton(
                      icon: Icon(Icons.search),
                      onPressed: () {
                        showSearch(context: context, delegate: DataSearch());
                      }),
                  IconButton(
                    icon: Icon(Icons.person),
                    onPressed: () {
                      _scaffoldkey.currentState.openEndDrawer();
                    },
                  ),
                  SizedBox(
                    width: 15,
                  )
                ],
              ),
              endDrawer: _endDrawer,
              drawer: _drawer,
              body: child,
            ),
          );
        },
        locale: _locale,
        supportedLocales: [
          Locale("en", "US"),
          Locale("ar", "SA"),
        ],
        localizationsDelegates: [
          DemoLocalization.delegate,
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        localeResolutionCallback: (locale, supportedLocales) {
          for (var supportedLocale in supportedLocales) {
            if (supportedLocale.languageCode == locale?.languageCode &&
                supportedLocale.countryCode == locale?.countryCode) {
              return supportedLocale;
            }
          }
          return supportedLocales.first;
        },
        home: Home(),
        //initialRoute: HomeRoute,
        navigatorKey: navKey,
        onGenerateRoute: RouteGenerator.generateRoute,
        //home: MyHomePage(title: 'Movie United'),
      );
    }
  }
}

class DataSearch extends SearchDelegate<String> {
  final emptyList = [
    'Type title to search.',
  ];

  @override
  List<Widget> buildActions(BuildContext context) {
    return [
      IconButton(
        icon: Icon(Icons.clear),
        onPressed: () {
          query = '';
        },
      )
    ];
  }

  @override
  Widget buildLeading(BuildContext context) {
    return IconButton(
      icon: AnimatedIcon(
          icon: AnimatedIcons.menu_arrow, progress: transitionAnimation),
      onPressed: () {
        close(context, '');
      },
    );
  }

  @override
  Widget buildResults(BuildContext context) {
    return Text('');
  }

  @override
  Widget buildSuggestions(BuildContext context) {
    if (query.isEmpty) {
      return ListView.builder(
        itemBuilder: (context, index) => ListTile(
          title: Text(emptyList[index]),
        ),
        itemCount: emptyList.length,
      );
    } else if (query.length >= 2) {
      return SingleChildScrollView(
          child: Container(
              child: Column(children: [
        new StreamBuilder<QuerySnapshot>(
            stream: (query != '' && query != null)
                ? FirebaseFirestore.instance
                    .collection('movies')
                    .where('searchKey', arrayContains: query.toLowerCase())
                    .snapshots()
                : FirebaseFirestore.instance.collection('movies').snapshots(),
            builder: (context, snapshot) {
              return (snapshot.connectionState == ConnectionState.waiting)
                  ? Center(
                      child: CircularProgressIndicator(
                      valueColor: AlwaysStoppedAnimation<Color>(kPrimaryColor),
                    ))
                  : ListView.builder(
                      shrinkWrap: true,
                      itemCount: snapshot.data.docs.length,
                      itemBuilder: (context, index) {
                        DocumentSnapshot data = snapshot.data.docs[index];
                        return Container(
                            height: 80,
                            decoration: BoxDecoration(
                                border: Border(bottom: BorderSide())),
                            child: ListTile(
                              onTap: () {
                                navKey.currentState.pushNamed(PreviewRoute,
                                    arguments: data.id);
                                close(context, '');
                              },
                              leading: Container(
                                child: StreamBuilder(
                                  stream: FirebaseStorage.instance
                                      .ref()
                                      .child(data['movieImg'])
                                      .getDownloadURL()
                                      .asStream(),
                                  builder: (context, snapshot) {
                                    if (snapshot.connectionState ==
                                        ConnectionState.waiting) {
                                      return CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                kPrimaryColor),
                                      );
                                    }
                                    return Container(
                                        width: 40.5,
                                        height: 60,
                                        child: Image.network(
                                            snapshot.data.toString(),
                                            fit: BoxFit.cover));
                                  },
                                ),
                              ),
                              title: Text(
                                data['movieName'],
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                data['movieDescription'],
                                maxLines: 3,
                              ),
                            ));
                      });
            }),
        new StreamBuilder<QuerySnapshot>(
            stream: (query != '' && query != null)
                ? FirebaseFirestore.instance
                    .collection('tvSeries')
                    .where('searchKey', arrayContains: query.toLowerCase())
                    .snapshots()
                : FirebaseFirestore.instance.collection('tvSeries').snapshots(),
            builder: (context, snapshot) {
              return (snapshot.connectionState == ConnectionState.waiting)
                  ? Center(
                      child: Text(""),
                    )
                  : ListView.builder(
                      shrinkWrap: true,
                      itemCount: snapshot.data.docs.length,
                      itemBuilder: (context, index) {
                        DocumentSnapshot data = snapshot.data.docs[index];
                        return Container(
                            height: 80,
                            decoration: BoxDecoration(
                                border: Border(bottom: BorderSide())),
                            child: ListTile(
                              onTap: () {
                                navKey.currentState.pushNamed(TvPreviewRoute,
                                    arguments: data.id);
                                close(context, '');
                              },
                              leading: Container(
                                child: StreamBuilder(
                                  stream: FirebaseStorage.instance
                                      .ref()
                                      .child(data['tvImg'])
                                      .getDownloadURL()
                                      .asStream(),
                                  builder: (context, snapshot) {
                                    if (snapshot.connectionState ==
                                        ConnectionState.waiting) {
                                      return CircularProgressIndicator(
                                        valueColor:
                                            AlwaysStoppedAnimation<Color>(
                                                kPrimaryColor),
                                      );
                                    }
                                    return Container(
                                        width: 40.5,
                                        height: 60,
                                        child: Image.network(
                                            snapshot.data.toString(),
                                            fit: BoxFit.cover));
                                  },
                                ),
                              ),
                              title: Text(
                                data['tvName'],
                                style: TextStyle(fontWeight: FontWeight.bold),
                              ),
                              subtitle: Text(
                                data['tvDescription'],
                                maxLines: 3,
                              ),
                            ));
                      });
            })
      ])));
    } else {
      return ListView.builder(
        itemBuilder: (context, index) => ListTile(
          title: Text(emptyList[index]),
        ),
        itemCount: emptyList.length,
      );
    }
  }
}
