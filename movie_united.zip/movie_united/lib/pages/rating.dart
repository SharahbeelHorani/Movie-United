import "package:flutter/material.dart";
import 'package:movie_united/constants/constants.dart';
import 'package:movie_united/localization/language_constants.dart';


import 'Components/footer.dart';
import 'Components/movieRate.dart';
import 'Components/tvRate.dart';

class Rating extends StatefulWidget {
  const Rating({ Key key }) : super(key: key);

  @override
  _RatingState createState() => _RatingState();
}

class _RatingState extends State<Rating> {
   PageController _pageController;
  int _selectedPage = 0;

  void _changePage(int pageNum) {
    setState(() {
      _selectedPage = pageNum;
      _pageController.animateToPage(pageNum,
          duration: Duration(milliseconds: 500),
          curve: Curves.fastLinearToSlowEaseIn);
    });
  }

  @override
  void initState() {
    _pageController = PageController();
    super.initState();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        width: double.infinity,
        color: kFullBlack,
        child: SafeArea(
          child: Column(children: [
            Container(
              padding: EdgeInsets.all(kDefaultPadding),
              constraints: BoxConstraints(maxWidth: kMaxWidth),
              height: MediaQuery.of(context).size.height - 55.0,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                      padding: EdgeInsets.symmetric(vertical: 12),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        children: [
                          TabButton(
                            text: getTranslated(context, "movies"),
                            pageNumber: 0,
                            selectedPage: _selectedPage,
                            onPressed: () {
                              _changePage(0);
                            },
                          ),
                          SizedBox(width: 20),
                          TabButton(
                            text: getTranslated(context, "tv_series"),
                            pageNumber: 1,
                            selectedPage: _selectedPage,
                            onPressed: () {
                              _changePage(1);
                            },
                          ),
                        ],
                      )),
                  Flexible(
                    child: PageView(
                      onPageChanged: (int page) {
                        setState(() {
                          _selectedPage = page;
                        });
                      },
                      controller: _pageController,
                      children: [
                        MovieRate(),
                        TvRate(),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            FooterWeb(),
          ]),

        ),
      ),
    );
  }
}

class TabButton extends StatelessWidget {
  final String text;
  final int selectedPage;
  final int pageNumber;
  final VoidCallback onPressed;
  TabButton({@required this.text, @required this.selectedPage, @required this.pageNumber, this.onPressed});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onPressed,
      child: AnimatedContainer(
        duration: Duration(milliseconds: 1000),
        curve: Curves.fastLinearToSlowEaseIn,
        decoration: BoxDecoration(
          color: selectedPage == pageNumber ? kPrimaryColor : kFullBlack,
          borderRadius: BorderRadius.circular(4.0),
        ),
        padding: EdgeInsets.symmetric(
          vertical: selectedPage == pageNumber ? 12.0 : 0,
          horizontal: selectedPage == pageNumber ? 20.0 : 0,
        ),
        margin: EdgeInsets.symmetric(
          vertical: selectedPage == pageNumber ? 0 : 12.0,
          horizontal: selectedPage == pageNumber ? 0 : 20.0,
        ),
        child: Text(
          text,
          style: TextStyle(color: Colors.white),
        ),
      ),
    );
  }
}
