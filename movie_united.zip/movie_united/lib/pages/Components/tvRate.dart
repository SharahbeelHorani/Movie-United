import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:movie_united/localization/language_constants.dart';
import 'package:rxdart/rxdart.dart';

import '../tvPreview.dart';

class TvRate extends StatefulWidget {
  const TvRate({Key key}) : super(key: key);

  @override
  _TvRateState createState() => _TvRateState();
}

class _TvRateState extends State<TvRate> {
  @override
  final FirebaseAuth auth = FirebaseAuth.instance;
  inputData() {
    String uid = "";
    final User user = auth.currentUser;
    if (user != null) {
      return (uid = user.uid);
    } else
      return (uid = "No");
  }

  getList() {
      Map ls = {};
      var firebaseUser = FirebaseAuth.instance.currentUser;
      FirebaseFirestore.instance
          .collection('ratings')
          .doc(firebaseUser.uid)
          .get()
          .then((DocumentSnapshot documentSnapshot) {
        if (documentSnapshot.exists) {
          ls = documentSnapshot.get('tvList');
        }
      }).then((value) {
        if (ls.length >= 0 && c < 1) {
          setState(() {
            fl = ls;
          });
          c++;
        }
      });
      return fl;
    }

  Map fl = {};
  int c = 0;
  int current = 0;
  Widget build(BuildContext context) {
    List<Stream> stbatch = [];
    int batches = 1;
    int remaining = 0;
    int pages = 1;

    getList() {
      Map ls = {};
      var firebaseUser = FirebaseAuth.instance.currentUser;
      FirebaseFirestore.instance
          .collection('ratings')
          .doc(firebaseUser.uid)
          .get()
          .then((DocumentSnapshot documentSnapshot) {
        if (documentSnapshot.exists) {
          ls = documentSnapshot.get('tvList');
        }
      }).then((value) {
        if (ls.length >= 0 && c < 1) {
          setState(() {
            fl = ls;
          });
          c++;
        }
      });
      return fl;
    }
    if (getList().length != 0)
    {
      setState(() {
        batches = getList().length ~/ 10;
        remaining = getList().length % 10;
      });
      if (remaining > 0) {
        setState(() {
          pages = batches + 1;
        });
      }
      for (int c = 0; c <= batches; c++) {
        if (c < batches) {
          setState(() {
            stbatch.add(FirebaseFirestore.instance
                .collection('tvSeries')
                .where('tvId',
                    whereIn: getList().keys.toList().sublist(c * 10, (c * 10) + 10))
                .snapshots());
          });
        } else {
          setState(() {
            stbatch.add(FirebaseFirestore.instance
                .collection('tvSeries')
                .where('tvId',
                    whereIn: getList().keys.toList().sublist((c * 10), remaining + (c * 10)))
                .snapshots());
          });
        }
      }
    } else {
      setState(() {
        stbatch.add((FirebaseFirestore.instance
            .collection("tvSeries")
            .where("tvId", whereIn: ['7JTcbInEtVb0h59PX']).snapshots()));
      });
    }


    return Container(
      child: ListView(
        shrinkWrap: true,
        physics: ClampingScrollPhysics(),
        children: [
          Container(
            color: kDarkBlackColor,
            child: StreamBuilder(
              stream: Rx.combineLatestList(stbatch).asBroadcastStream(),
              // ignore: missing_return
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data[current].docs == null || snapshot.connectionState== ConnectionState.waiting || snapshot.data[current].docs.length == 0) {
                  return Container(height: 30,child: Center(child: Text(getTranslated(context, "no_tv_rate_yet"), style: TextStyle(color: Colors.white, fontSize: 12))));
                } else if (snapshot.data[current].docs.length > 0) {
                  return DataTable(
                    columnSpacing: 0,
                    showCheckboxColumn: false,
                    dataRowHeight: 80,
                    columns: [
                      DataColumn(
                          label: Text(getTranslated(context, "tv_series_title"),
                              style: TextStyle(
                                  fontSize: 14,
                                  color: kBgColor,
                                  fontWeight: FontWeight.bold))),
                      DataColumn(
                          label: Text(getTranslated(context, "your_rate"),
                              style: TextStyle(
                                  fontSize: 14,
                                  color: Colors.yellow,
                                  fontWeight: FontWeight.bold))),
                    ],
                    rows: _buildList(context, snapshot.data[current].docs),
                    
                  );
                }
                else
                  return(Container());
              },
            ),
          ),
          Container(
            color: kDarkBlackColor,
            height: 60,
            width: 20,
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Spacer(),
                (current + 1) != 1
                    ? InkWell(
                        child: Icon(Icons.arrow_left,
                            color: kPrimaryColor, size: 40),
                        onTap: () {
                          setState(() {
                            current = current - 1;
                          });
                        })
                    : InkWell(
                        child:
                            Icon(Icons.arrow_left, color: kFullBlack, size: 40),
                        onTap: () {}),
                Text(
                  getTranslated(context, "page") + " " +
                      (current + 1).toString() +
                      " " + getTranslated(context, "of") + " " +
                      pages.toString(),
                  style: TextStyle(color: Colors.white),
                ),
                (current + 1) != pages
                    ? InkWell(
                        child: Icon(Icons.arrow_right,
                            color: kPrimaryColor, size: 40),
                        onTap: () {
                          setState(() {
                            current = current + 1;
                          });
                        },
                      )
                    : InkWell(
                        child: Icon(Icons.arrow_right,
                            color: kFullBlack, size: 40),
                        onTap: () {},
                      ),
                Spacer(),
                Text(getTranslated(context, "total") + ": " + getList().length.toString(), style:TextStyle(color: kBodyTextColor))
              ],
            ),
          ),
          SizedBox(height: 50)
        ],
      ),
    );
  }

  List<DataRow> _buildList(
      BuildContext context, List<DocumentSnapshot> snapshot) {
    return snapshot.map((data) => _buildListItem(context, data)).toList();
  }

  DataRow _buildListItem(BuildContext context, DocumentSnapshot data) {
    final record = Record.fromSnapshot(data);

    return DataRow(
      cells: [
        DataCell(
          Container(
            width: MediaQuery.of(context).size.width/2,
            child: ListTile(
              contentPadding: EdgeInsets.symmetric(vertical:-10, horizontal: -10),
              leading: Container(
                child: StreamBuilder(
                  stream: record.imgURL().asStream(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(kPrimaryColor),);
                    }
                    return Container(
                        width: 40.5, height: 60, child: Image.network(snapshot.data.toString(),fit: BoxFit.cover));
                  },
                ),
              ),
              title: Text(
                record.tvName,
                style: TextStyle(
                  color: Colors.white, fontSize: 12),
              ),
              subtitle: Text(
                record.tvRating.toString() + "/10",
                style: TextStyle(
                  color: Colors.grey,fontSize: 10),
              ),
            ),
          ),
        ),

        DataCell(Text(fl[data.id].toString(),
            style: TextStyle(
              color: Colors.yellow,fontSize: 12
            ))),
      ],
        onSelectChanged: (newValue) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => TvPreview(tvId: data.id)),);
        }
    );
  }
}

class Record {
  final String tvName;
  final num tvRating;
  final String tvImg;
  final DocumentReference reference;
  final String tvId;

  Future imgURL() {
    return FirebaseStorage.instance.ref().
    child(tvImg).getDownloadURL();
  }

  Record.fromMap(Map<String, dynamic> map, {@required this.reference})
      : assert(map['tvName'] != null),
        assert(map['tvRating'] != null),
        assert(map['tvImg'] != null),
        assert(map['tvId'] != null),
        tvName = map['tvName'],
        tvId = map['tvId'],
        tvRating = map['tvRating'],
        tvImg = map['tvImg'];

  Record.fromSnapshot(DocumentSnapshot snapshot)
      : this.fromMap(snapshot.data() as Map<String, dynamic>, reference: snapshot.reference);

  @override
  String toString() => "Record<$tvName:$tvRating:$tvId>";
}
