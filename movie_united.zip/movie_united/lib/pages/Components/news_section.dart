import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:movie_united/constants/constants.dart';

class NewsSection extends StatelessWidget {
  var newFormat = DateFormat("MM-dd-yyyy");
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220,
      child: StreamBuilder<QuerySnapshot>(
          stream: FirebaseFirestore.instance
              .collection('news')
              .orderBy('dateAdded', descending: true)
              .limit(3)
              .snapshots(),
          builder:
              (BuildContext context, AsyncSnapshot<QuerySnapshot> snapshot) {
            if (snapshot.hasError) return new Text('Error: ${snapshot.error}');
            switch (snapshot.connectionState) {
              case ConnectionState.waiting:
                return new Text('Loading...');
              default:
                return new ListView(
                  shrinkWrap: true,
                  physics: ClampingScrollPhysics(),
                  children: snapshot.data.docs.map((DocumentSnapshot document) {
                    return new Card(
                      elevation: 5,
                      shadowColor: kPrimaryColor,
                      color: kDarkBlackColor,
                      
                        child: Wrap(
                          children: <Widget>[
                            ListTile(
                              leading: SizedBox(
                                height: 120,
                                width: 40,
                                child: ClipRRect(
                                  child: FutureBuilder(
                                    future: FirebaseStorage.instance
                                        .ref()
                                        .child(document['newsImg'])
                                        .getDownloadURL(),
                                    builder: (context, snapshot) {
                                      if (snapshot.connectionState ==
                                          ConnectionState.waiting) {
                                        return Center(
                                            child: CircularProgressIndicator(
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                                  kPrimaryColor),
                                        ));
                                      }
                                      return Container(
                                          width: 120,
                                          child: Image.network(
                                              snapshot.data.toString(),
                                              height: 120.0,
                                              width: 120,
                                              fit: BoxFit.fill));
                                    },
                                  ),
                                ),
                              ),
                              title: Row(
                                children: [
                                  Container(
                                    width: MediaQuery.of(context).size.width/2,
                                    
                                      child: Text(
                                        document['newsTitle'],
                                        style: TextStyle(
                                            color: kPrimaryColor,
                                            fontWeight: FontWeight.bold,
                                            fontSize: 14),
                                      ),
                                    ),
                                  
                                  Spacer(),
                                  Text(
                                    newFormat
                                        .format(document['dateAdded'].toDate()),
                                    style: TextStyle(
                                        fontSize: 10,
                                        color: kBodyTextColor,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                              subtitle: Text(
                                document['newsDescription'],
                                style:
                                    TextStyle(color: Colors.white, fontSize: 12),
                              ),
                            ),
                          ],
                        ),
                      
                    );
                  }).toList(),
                );
            }
          }),
    );
  }
}
