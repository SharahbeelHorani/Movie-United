import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:url_launcher/url_launcher.dart';

class FooterWeb extends StatelessWidget {
  final _urlInstagram =
      'https://instagram.com/movie_united?utm_medium=copy_link';
  final _urlTikTok =
      'https://www.tiktok.com/@movie_united?sender_device=mobile&sender_web_id=&is_from_webapp=v2&is_copy_url=0';

  @override
  Widget build(BuildContext context) {
    return Container(
        height: 180.0,
        width: double.infinity,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
                width: 60,
                child: Image.asset(
                  'assets/images/Logo.png',
                )),
            Row(
              children: [
                IconButton(
                    icon: Icon(FontAwesomeIcons.tiktok),
                    tooltip: 'TikTok',
                    color: kPrimaryColor,
                    onPressed: () {
                      _launchURLTikTok();
                    }),
               // SizedBox(width: 5.0),
                IconButton(
                    icon: Icon(FontAwesomeIcons.instagram),
                    tooltip: 'Instagram',
                    color: kPrimaryColor,
                    onPressed: () {
                      _launchURLInstagram();
                    }),
              ],
            ),
            Text(
              'Designed by Alazware.com.',
              maxLines: 3,
              style: TextStyle(fontSize: 8, color: kBodyTextColor),
            )
          ],
        ));
  }

  void _launchURLInstagram() async => await canLaunch(_urlInstagram)
      ? await launch(_urlInstagram)
      : throw 'Could not launch $_urlInstagram';
  void _launchURLTikTok() async => await canLaunch(_urlTikTok)
      ? await launch(_urlTikTok)
      : throw 'Could not launch $_urlTikTok';
}
