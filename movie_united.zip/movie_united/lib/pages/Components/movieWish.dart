
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:movie_united/localization/language_constants.dart';
import 'package:rxdart/rxdart.dart';

import '../preview.dart';

class MovieWish extends StatefulWidget {
  const MovieWish({Key key}) : super(key: key);

  @override
  _MovieWishState createState() => _MovieWishState();
}

class _MovieWishState extends State<MovieWish> {
  @override
  final FirebaseAuth auth = FirebaseAuth.instance;
  inputData() {
    String uid = "";
    final User user = auth.currentUser;
    if (user != null) {
      return (uid = user.uid);
    } else
      return (uid = "No");
  }

  getList() {
    List ls = [''];
    var firebaseUser = FirebaseAuth.instance.currentUser;
    FirebaseFirestore.instance
        .collection('watchlist')
        .doc(firebaseUser.uid)
        .get()
        .then((DocumentSnapshot documentSnapshot) {
      if (documentSnapshot.exists) {
        ls = documentSnapshot.get('movieList');
      }
    }).then((value) {
      if (ls.length >= 0 && c < 1) {
        setState(() {
          fl = ls;
        });
        c++;
      }
    });
    return fl;
  }

  List fl = [];
  int c = 0;
  int current = 0;

  Widget build(BuildContext context) {
    List<Stream> stbatch = [];
    int batches = 1;
    int remaining = 0;
    int pages = 1;

    getList() {
      List ls = [''];
      var firebaseUser = FirebaseAuth.instance.currentUser;
      FirebaseFirestore.instance
          .collection('watchlist')
          .doc(firebaseUser.uid)
          .get()
          .then((DocumentSnapshot documentSnapshot) {
        if (documentSnapshot.exists) {
          ls = documentSnapshot.get('movieList');
        }
      }).then((value) {
        if (ls.length >= 0 && c < 1) {
          setState(() {
            fl = ls;
          });
          c++;
        }
      });
      return fl;
    }
    if (getList().length != 0) {
      setState(() {
        batches = getList().length ~/ 10;
        remaining = getList().length % 10;
      });
      if (remaining > 0) {
        setState(() {
          pages = batches + 1;
        });
      }

      for (int c = 0; c <= batches; c++) {
        if (c < batches) {
          setState(() {
            stbatch.add(FirebaseFirestore.instance
                .collection('movies')
                .where('movieId',
                    whereIn: getList().sublist(c * 10, (c * 10) + 10))
                .snapshots());
          });
        } else {
          setState(() {
            stbatch.add(FirebaseFirestore.instance
                .collection('movies')
                .where('movieId',
                    whereIn: getList().sublist((c * 10), remaining + (c * 10)))
                .snapshots());
          });
        }
      }
    } else {
      setState(() {
        stbatch.add(FirebaseFirestore.instance
            .collection("movies")
            .where("movieId", whereIn: ['7JTcbInEtVb0h59PX']).snapshots());
      });
    }

    return Container(
      child: ListView(
        shrinkWrap: true,
        physics: ClampingScrollPhysics(),
        children: [
          Container(
            color: kDarkBlackColor,
            child: StreamBuilder(
              stream: Rx.combineLatestList(stbatch).asBroadcastStream(),
              // ignore: missing_return
              builder: (context, snapshot) {
                if (!snapshot.hasData || snapshot.data[current].docs == null || snapshot.connectionState== ConnectionState.waiting || snapshot.data[current].docs.length == 0) {
                  return Container(height: 30,child: Center(child: Text(getTranslated(context, 'your_movie_watchlist_is_empty'), style: TextStyle(color: Colors.white, fontSize: 12))));
                } else if (snapshot.data[current].docs.length > 0) {
                  return DataTable(
                    columnSpacing: 0,
                    showCheckboxColumn: false,
                    dataRowHeight: 80,
                    columns: [
                      DataColumn(
                          label: Text(getTranslated(context, "movie_title"),
                              style: TextStyle(
                                  fontSize: 14,
                                  color: kBgColor,
                                  fontWeight: FontWeight.bold))),
                      DataColumn(
                          label: Text(getTranslated(context, "rating"),
                              style: TextStyle(
                                  fontSize: 14,
                                  color: kBgColor,
                                  fontWeight: FontWeight.bold))),
                      ],
                    rows: _buildList(context, snapshot.data[current].docs),
                  );
                }
                else
                  return (Container());
              },
            ),
          ),
          Container(
            color: kDarkBlackColor,
            height: 60,
            width: 20,
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Spacer(),
                (current + 1) != 1
                    ? InkWell(
                        child: Icon(Icons.arrow_left,
                            color: kPrimaryColor, size: 40),
                        onTap: () {
                          setState(() {
                            current = current - 1;
                          });
                        })
                    : InkWell(
                        child:
                            Icon(Icons.arrow_left, color: kFullBlack, size: 40),
                        onTap: () {}),
                Text(
                  
                  getTranslated(context, "page") + " " +
                      (current + 1).toString() +
                      " " + getTranslated(context, "of") + " " +
                      pages.toString(),
                  style: TextStyle(color: Colors.white),
                ),
                (current + 1) != pages
                    ? InkWell(
                        child: Icon(Icons.arrow_right,
                            color: kPrimaryColor, size: 40),
                        onTap: () {
                          setState(() {
                            current = current + 1;
                          });
                        },
                      )
                    : InkWell(
                        child: Icon(Icons.arrow_right,
                            color: kFullBlack, size: 40),
                        onTap: () {},
                      ),
                Spacer(),
                Text(getTranslated(context, "total") + ": " + getList().length.toString(), style:TextStyle(color: kBodyTextColor))
              ],
            ),
          ),
          SizedBox(height: 50),
        ],
      ),
    );
  }

  List<DataRow> _buildList(
      BuildContext context, List<DocumentSnapshot> snapshot) {
    return snapshot.map((data) => _buildListItem(context, data)).toList();
  }

  DataRow _buildListItem(BuildContext context, DocumentSnapshot data) {
    final record = Record.fromSnapshot(data);

    return DataRow(
      cells: [
        DataCell(
          Container(
            width: MediaQuery.of(context).size.width/2,
            child: ListTile(
              contentPadding: EdgeInsets.symmetric(vertical:-10, horizontal: -10),
              leading: Container(
                child: StreamBuilder(
                  stream: record.imgURL().asStream(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(kPrimaryColor),);
                    }
                    return Container(
                        width: 40.5, height: 60, child: Image.network(snapshot.data.toString(),fit: BoxFit.cover));
                  },
                ),
              ),
              title: Text(
                record.movieName,
                style: TextStyle(
                  color: Colors.white, fontSize: 12),
              ),
              subtitle: Text(
                record.movieGenre,
                style: TextStyle(
                  color: Colors.grey, fontSize: 10),
              ),


            ),
          ),
        ),
        DataCell(Row(
          children: [
            Icon(Icons.star, color: Colors.yellow, size: 14),
            Text( " " +
                record.movieRating.toString(),
              style: TextStyle(
                color: kBgColor,fontSize: 12
              ),
            ),
          ],
        )),

      ],
        onSelectChanged: (newValue) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => Preview(movId: data.id)),);
        }
    );
  }
}

class Record {
  final String movieName;
  final String movieGenre;
  final num movieRating;
  final String movieImg;
  final DocumentReference reference;
  final String movieId;

  Future imgURL() {
    return FirebaseStorage.instance.ref().
    child(movieImg).getDownloadURL();
  }

  Record.fromMap(Map<String, dynamic> map, {@required this.reference})
      : assert(map['movieName'] != null),
        assert(map['movieGenre'] != null),
        assert(map['movieRating'] != null),
        assert(map['movieImg'] != null),
        assert(map['movieId'] != null),
        movieName = map['movieName'],
        movieId = map['movieId'],
        movieGenre = map['movieGenre'].join(", "),
        movieRating = map['movieRating'],
        movieImg = map['movieImg'];

  Record.fromSnapshot(DocumentSnapshot snapshot)
      : this.fromMap(snapshot.data() as Map<String, dynamic>, reference: snapshot.reference);

  @override
  String toString() => "Record<$movieName:$movieRating:$movieGenre:$movieId>";
}
