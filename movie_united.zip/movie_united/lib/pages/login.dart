import 'package:fialogs/fialogs.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:get/get.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:movie_united/localization/language_constants.dart';
import 'package:movie_united/pages/register.dart';

import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';



class Login extends StatefulWidget {
  final BuildContext bcx;
  const Login({Key key, this.bcx}) : super(key: key);

  @override
  _LoginState createState() => _LoginState();
}

final FirebaseAuth auth = FirebaseAuth.instance;
String lname = '';
String fname = '';
inputData() {
  String uid = "";
  final User user = auth.currentUser;
  if (user != null) {
    return (uid = user.displayName);
  } else
    return (uid = "No");
}

class _LoginState extends State<Login> {
  final _formKeyL = GlobalKey<FormState>();
  final _fbKeyn = GlobalKey<FormBuilderState>();
   String newEmail;
   String userEmail;
   String displayName;
  bool isLogged = false;

  bool validateAndSaveL() {
    final formL = _formKeyL.currentState;
    if (formL.validate()) {
      formL.save();
      return true;
    }
    return false;
  }

  void validateAndSubmitL() async {
    if (validateAndSaveL()) {
      try {
        UserCredential user = await FirebaseAuth.instance
            .signInWithEmailAndPassword(email: _email, password: _password);
        print('Signed In: ${user.user}');
        setState(() {
          isLogged = true;
          userEmail = user.user.email;
          displayName = user.user.displayName;
        });

        showTopSnackBar(
          context,
          CustomSnackBar.success(
            message: "Hello $displayName !",
          ),
        );
        Navigator.of(context).pop();

      } catch (e) {
        print('error $e');
        showTopSnackBar(
          context,
          CustomSnackBar.error(
            message: getTranslated(widget.bcx, "email_or_password_incorrect"),
          ),
        );
      }
    }
  }

   String _email;
   String _password;
   String _passwordR;
  String _fname = "default";
  String _lname = "defaulT";
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Material(
        child: Container(
          width: double.infinity,
          color: kFullBlack,
          child: SafeArea(
            child: Column(
              children: [
                Container(
                  constraints: BoxConstraints(maxWidth: kMaxWidth),
                  child: Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width ,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5.0),
                      color: kDarkBlackColor,
                      boxShadow: [
                        BoxShadow(
                          color: kPrimaryColor,
                          offset: Offset(0.0, 0.0), //(x,y)
                          blurRadius: 20.0,
                        ),
                      ],
                    ),
                    child: Form(
                      key: _formKeyL,
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Spacer(),
                              Padding(
                                padding: const EdgeInsets.all(18.0),
                                child: InkWell(
                                  onTap: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Icon(
                                    Icons.cancel,
                                    color: Colors.white,
                                    size: 30,
                                  ),
                                ),
                              )
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.all(18.0),
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5.0),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: kPrimaryColor,
                                    offset: Offset(0.0, 0.0), //(x,y)
                                    blurRadius: 20.0,
                                  ),
                                ],
                              ),
                              height: MediaQuery.of(context).size.height / 1.2,
                              width: 400,
                              child: ListView(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 8),
                                  ),
                                  Text(
                                    "Movie United",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: kPrimaryColor,
                                        fontSize: 25,
                                        fontWeight: FontWeight.w900),
                                  ),
                                  Padding(
                                    padding:
                                    EdgeInsets.symmetric(horizontal: 80),
                                    child: Text(
                                     getTranslated(widget.bcx, "sign_in"),
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: kPrimaryColor,
                                        fontSize: 30,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 16),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 16),
                                    child: TextFormField(
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        filled: true,
                                        fillColor: Colors.white,
                                        hintText: getTranslated(widget.bcx, "email"),
                                      ),
                                      validator: (value) => value.isEmpty
                                          ? getTranslated(widget.bcx, "please_enter_valid_email_address")
                                          : null,
                                      onSaved: (value) => _email = value,
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 16),
                                    child: TextFormField(
                                      // ignore: deprecated_member_use
                                      obscureText: true,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        filled: true,
                                        fillColor: Colors.white,
                                        hintText: getTranslated(widget.bcx, "password"),
                                      ),
                                      validator: (value) => value.isEmpty
                                          ? getTranslated(widget.bcx, "please_enter_your_password")
                                          : null,
                                      onSaved: (value) => _password = value,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        top: 40.0, left: 20, right: 20),
                                    child: ElevatedButton(
                                      child: Text(getTranslated(widget.bcx, "sign_in")),
                                      style: ElevatedButton.styleFrom(
                                        primary: kPrimaryColor,
                                      ),
                                      onPressed: () {
                                        validateAndSubmitL();

                                      },
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        top: 30.0, left: 20, right: 20),
                                    child: TextButton(
                                      child: Text(
                                        getTranslated(widget.bcx, "forgot_password"),
                                        style: TextStyle(fontSize: 12),
                                      ),
                                      onPressed: () {
                                        customDialog(
                                          context,
                                          title: Text(
                                            getTranslated(widget.bcx, "enter_email_address"),
                                            style: TextStyle(
                                              color: Colors.black,
                                              fontSize: 20,
                                            ),
                                          ),
                                          content: FormBuilder(
                                            key: _fbKeyn,
                                            child: Column(
                                              children: [
                                                TextFormField(
                                                  initialValue: '',
                                                  onChanged: (text) {
                                                    newEmail = text;
                                                  },
                                                  validator: (value) {
                                                    if (newEmail
                                                        .toString()
                                                        .length ==
                                                        0 ||
                                                        newEmail.toString() ==
                                                            '' ||
                                                        newEmail.toString() ==
                                                            null) {
                                                      return (getTranslated(widget.bcx, "this_field_cannot_be_empty"));
                                                    } else if (!newEmail
                                                        .isValidEmail()) {
                                                      return (getTranslated(widget.bcx, "invalid_email"));
                                                    }
                                                  },
                                                ),
                                                Divider(),
                                              ],
                                            ),
                                          ),
                                          positiveButtonText: "Reset",
                                          positiveButtonAction: () {
                                            if (_fbKeyn.currentState
                                                .validate()) {
                                              FirebaseAuth.instance
                                                  .sendPasswordResetEmail(
                                                  email: newEmail.trim());
                                              showTopSnackBar(
                                                context,
                                                CustomSnackBar.success(
                                                  message: getTranslated(widget.bcx, "new_password_has_been_sent_to_your_email"),
                                                ),
                                              );
                                              Navigator.of(context,
                                                  rootNavigator: true)
                                                  .pop();
                                            }

                                          },
                                          neutralButtonAction: () {
                                            Navigator.of(context,
                                                rootNavigator: true)
                                                .pop();
                                          },
                                          hideNeutralButton: false,
                                          closeOnBackPress: true,
                                        );
                                      },
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        top: 20.0, left: 20, right: 20),
                                    child: TextButton(
                                      child: Text(getTranslated(widget.bcx, "create_account")),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => Register(rtx: widget.bcx,)),
                                        );
                                      },
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          Spacer()
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
extension EmailValidator on String {
  bool isValidEmail() {
    return RegExp(
        r'^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$')
        .hasMatch(this);
  }
}

