import 'package:fialogs/fialogs.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
//import 'package:firebase/firebase.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_animated_dialog/flutter_animated_dialog.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:intl/intl.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:movie_united/localization/language_constants.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

import 'Components/footer.dart';
import 'login.dart';

class Preview extends StatefulWidget {
  final String movId;
  const Preview({@required this.movId});

  @override
  _PreviewState createState() => _PreviewState();
}

class _PreviewState extends State<Preview> {
  String movieName = '';
  num movieRating;
  String movieDescription = '';
  String movieGenre = '';
  String movieAge = '';
  String ytURL = '';
  bool exist = false;
  bool existR = false;
  inputData() {
    String uid = "";
    final User user = auth.currentUser;
    if (user != null) {
      return (uid = user.uid);
    } else
      return (uid = null);
  }

  final myController = TextEditingController();
  final _fbKey = GlobalKey<FormBuilderState>();
  final _fbKey1 = GlobalKey<FormBuilderState>();
  final myController1 = TextEditingController();
  final myController2 = TextEditingController();
  final db = FirebaseFirestore.instance;
  int i = 0;
  int j = 0;
  int r = 0;
  String rating;
  num newRat = 8;
  String movieId = '';
  @override
  Widget build(BuildContext context) {
    setState(() {
      inputData();
      movieId = widget.movId;
    });
    print(movieId);
    return SingleChildScrollView(
      child: Container(
        width: double.infinity,
        color: kFullBlack,
        child: SafeArea(
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(kDefaultPadding),
                constraints: BoxConstraints(maxWidth: kMaxWidth),
                child: Column(
                  children: [
                    new StreamBuilder<DocumentSnapshot>(
                      stream: FirebaseFirestore.instance
                          .collection('movies')
                          .doc(widget.movId)
                          .snapshots(),
                      builder: (context, snapshot) {
                        if (!snapshot.hasData) {
                          return new Text("Loading");
                        }
                        var userDocument = snapshot.data;
                        movieName = userDocument["movieName"];
                        movieRating = userDocument["movieRating"];
                        movieDescription = userDocument["movieDescription"];
                        movieAge = userDocument["movieAge"];
                        movieGenre = userDocument["movieGenre"].join(' - ');
                        ytURL = userDocument["ytURL"];
                        // ignore: close_sinks
                        YoutubePlayerController _controller1 =
                            YoutubePlayerController(
                          initialVideoId: ytURL,
                          params: YoutubePlayerParams(
                            startAt: Duration(seconds: 0),
                            showControls: true,
                            showFullscreenButton: true,
                          ),
                        );
                        return (Column(
                          children: [
                            Row(
                              children: [
                                /*FlatButton(
                                  color: Colors.red,
                                  onPressed: () {
                                    Navigator.pop(context);
                                  },
                                  child: Text('Go back!'),
                                ),*/

                                Container(
                                  width:
                                      MediaQuery.of(context).size.width / 1.5,
                                  child: Text(
                                    movieName,
                                    style: TextStyle(
                                      color: kBgColor,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w900,
                                    ),
                                  ),
                                ),
                                Spacer(),
                                Container(
                                    width: 18,
                                    child: Image.asset(
                                      'assets/images/star.png',
                                      width: 10,
                                    )),
                                Text(
                                  " " + movieRating.toString(),
                                  style: TextStyle(
                                      color: kBgColor,
                                      fontSize: 22,
                                      fontWeight: FontWeight.w900),
                                ),
                                Text(
                                  '/10',
                                  style: TextStyle(
                                      color: kBodyTextColor,
                                      fontSize: 18,
                                      fontWeight: FontWeight.w900),
                                ),
                              ],
                            ),
                            SizedBox(height: kDefaultPadding * 2),
                            YoutubePlayerIFrame(
                              controller: _controller1,
                              aspectRatio: 16 / 9,
                            ),
                            SizedBox(height: kDefaultPadding * 2),
                            Row(
                              children: [
                                Spacer(),
                                inputData() != null
                                    ? watchList()
                                    : Text(
                                        "",
                                        style: TextStyle(
                                            color: kBodyTextColor, fontSize: 8),
                                      ),
                                SizedBox(
                                  width: 10,
                                ),
                                inputData() != null
                                    ? ratings()
                                    : Text(
                                        getTranslated(context,
                                            "sign_in_to_add_to_watchlsit"),
                                        style: TextStyle(
                                            color: kBodyTextColor, fontSize: 8),
                                      ),

                                //Align(alignment: Alignment.centerRight, child: IconButton(onPressed: (){}, icon: Icon(Icons.bookmark_add, color: Colors.white,))),
                              ],
                            ),
                            SizedBox(height: kDefaultPadding * 2),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                getTranslated(context, "description"),
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: kBodyTextColor,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                movieDescription,
                                softWrap: true,
                                maxLines: 3,
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            SizedBox(height: kDefaultPadding * 2),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                getTranslated(context, "genr"),
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: kBodyTextColor,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                movieGenre,
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            SizedBox(height: kDefaultPadding * 2),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                getTranslated(
                                    context, "motion_picture_rating_movie"),
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: kBodyTextColor,
                                  fontSize: 18,
                                ),
                              ),
                            ),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                movieAge,
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: Colors.white,
                                  fontSize: 14,
                                ),
                              ),
                            ),
                            SizedBox(height: kDefaultPadding * 3),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                getTranslated(context, "comment_section"),
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: kBodyTextColor,
                                  fontSize: 20,
                                ),
                              ),
                            ),
                            SizedBox(height: kDefaultPadding),
                            inputData() != null
                                ? post()
                                : Text(
                                    getTranslated(
                                        context, "sign_in_to_post_comment"),
                                    style: TextStyle(
                                        color: kBodyTextColor, fontSize: 8),
                                  ),
                            SizedBox(height: kDefaultPadding * 2),
                            Align(
                              alignment: Alignment.centerLeft,
                              child: Text(
                                getTranslated(context, "comments"),
                                textAlign: TextAlign.left,
                                style: TextStyle(
                                  color: kBodyTextColor,
                                  fontSize: 20,
                                ),
                              ),
                            ),
                            StreamBuilder<QuerySnapshot>(
                                stream: FirebaseFirestore.instance
                                    .collection("comments")
                                    .where("movieId", isEqualTo: movieId)
                                    .where("pID", isEqualTo: 'null')
                                    .orderBy("commentAt", descending: true)
                                    .snapshots(),
                                builder: (BuildContext context,
                                    AsyncSnapshot<QuerySnapshot> snapshot) {
                                  if (snapshot.hasError)
                                    print('Error: ${snapshot.error}');
                                  if (snapshot.connectionState ==
                                      ConnectionState.waiting)
                                    return new Text('Loading...');
                                  if (!snapshot.hasData ||
                                      snapshot.data.docs.length == 0)
                                    return new Text(
                                      getTranslated(context,
                                          "no_one_commented_on_this_movie"),
                                      style: TextStyle(
                                          color: kBodyTextColor, fontSize: 8),
                                    );
                                  else {
                                    return new ListView(
                                      shrinkWrap: true,
                                      physics: ClampingScrollPhysics(),
                                      children: snapshot.data.docs
                                          .map((DocumentSnapshot document) {
                                        return Column(
                                          children: [
                                            Container(
                                                child: comment(
                                                    document['userId'],
                                                    document['commentAt'],
                                                    document['comment'],
                                                    document.id,
                                                    document['likes'],
                                                    context)),
                                            StreamBuilder<QuerySnapshot>(
                                                stream: FirebaseFirestore
                                                    .instance
                                                    .collection("comments")
                                                    .where("movieId",
                                                        isEqualTo: movieId)
                                                    .where("pID",
                                                        isEqualTo: document.id)
                                                    .orderBy('commentAt',
                                                        descending: true)
                                                    .snapshots(),
                                                builder: (BuildContext context,
                                                    AsyncSnapshot<QuerySnapshot>
                                                        snapshot) {
                                                  if (snapshot.hasError)
                                                    print(
                                                        'Error: ${snapshot.error}');
                                                  if (snapshot
                                                          .connectionState ==
                                                      ConnectionState.waiting)
                                                    return new Text(
                                                        'Loading...');
                                                  if (!snapshot.hasData ||
                                                      snapshot.data.docs
                                                              .length ==
                                                          0)
                                                    return new Text("");
                                                  else {
                                                    return new ListView(
                                                      shrinkWrap: true,
                                                      physics:
                                                          ClampingScrollPhysics(),
                                                      children: snapshot
                                                          .data.docs
                                                          .map((DocumentSnapshot
                                                              docu) {
                                                        return Column(
                                                          children: [
                                                            Container(
                                                                child: innerComment(
                                                                    docu[
                                                                        'userId'],
                                                                    docu[
                                                                        'commentAt'],
                                                                    docu[
                                                                        'comment'],
                                                                    docu.id,
                                                                    docu[
                                                                        'likes'],
                                                                    context)),
                                                            StreamBuilder<
                                                                    QuerySnapshot>(
                                                                stream: FirebaseFirestore
                                                                    .instance
                                                                    .collection(
                                                                        "comments")
                                                                    .where(
                                                                        "movieId",
                                                                        isEqualTo:
                                                                            movieId)
                                                                    .where(
                                                                        "pID",
                                                                        isEqualTo:
                                                                            docu
                                                                                .id)
                                                                    .orderBy(
                                                                        'commentAt',
                                                                        descending:
                                                                            true)
                                                                    .snapshots(),
                                                                builder: (BuildContext
                                                                        context,
                                                                    AsyncSnapshot<
                                                                            QuerySnapshot>
                                                                        snapshot) {
                                                                  if (snapshot
                                                                      .hasError)
                                                                    print(
                                                                        'Error: ${snapshot.error}');
                                                                  if (snapshot
                                                                          .connectionState ==
                                                                      ConnectionState
                                                                          .waiting)
                                                                    return new Text(
                                                                        'Loading...');
                                                                  if (!snapshot
                                                                          .hasData ||
                                                                      snapshot
                                                                              .data
                                                                              .docs
                                                                              .length ==
                                                                          0)
                                                                    return new Text(
                                                                        "");
                                                                  else {
                                                                    return new ListView(
                                                                      shrinkWrap:
                                                                          true,
                                                                      physics:
                                                                          ClampingScrollPhysics(),
                                                                      children: snapshot
                                                                          .data
                                                                          .docs
                                                                          .map((DocumentSnapshot
                                                                              docu1) {
                                                                        return Column(
                                                                          children: [
                                                                            Container(child: thirdComment(docu1['userId'], docu1['commentAt'], docu1['comment'], docu1.id, docu1['likes'], context)),
                                                                          ],
                                                                        );
                                                                      }).toList(),
                                                                    );
                                                                  }
                                                                })
                                                          ],
                                                        );
                                                      }).toList(),
                                                    );
                                                  }
                                                })
                                          ],
                                        );
                                      }).toList(),
                                    );
                                  }
                                }),
                          ],
                        ));
                      },
                    ),
                    SizedBox(height: kDefaultPadding * 2),
                    FooterWeb(),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  watchList() {
    var firebaseUser = FirebaseAuth.instance.currentUser;

    FirebaseFirestore.instance
        .collection('watchlist')
        .doc(firebaseUser.uid)
        .get()
        .then((DocumentSnapshot documentSnapshot) {
      if (documentSnapshot.exists) {
        List ls = documentSnapshot.get('movieList');
        if (ls.contains(widget.movId) && i < 1) {
          setState(() {
            exist = true;
            i++;
          });
        } else if (!ls.contains(widget.movId) && i < 1) {
          setState(() {
            exist = false;
            i++;
          });
        }
      } else {
        print('Document does not exist on the database');
      }
    });

    if (exist != true) {
      return showExist();
    } else if (exist == true) {
      return showNotExist();
    }
  }

  showExist() {
    return (ElevatedButton(
      onPressed: () {
        setState(() {
          var firebaseUser = FirebaseAuth.instance.currentUser;
          i = 0;
          j = 0;
          r = 0;
          FirebaseFirestore.instance
              .collection("watchlist")
              .doc(firebaseUser.uid)
              .update({
            "movieList": FieldValue.arrayUnion([widget.movId])
          });
        });
      },
      style: ElevatedButton.styleFrom(
        primary: kPrimaryColor,
      ),
      child: Center(
        child: Row(
          children: [
            Icon(Icons.bookmark_add),
          ],
        ),
      ),
    ));
  }

  showNotExist() {
    return (ElevatedButton(
      onPressed: () {
        setState(() {
          var firebaseUser = FirebaseAuth.instance.currentUser;
          i = 0;
          j = 0;
          r = 0;
          FirebaseFirestore.instance
              .collection("watchlist")
              .doc(firebaseUser.uid)
              .update({
            "movieList": FieldValue.arrayRemove([widget.movId])
          });
        });
      },
      style: ElevatedButton.styleFrom(
        primary: kPrimaryColor,
      ),
      child: Center(
        child: Row(
          children: [
            Icon(Icons.bookmark_remove),
          ],
        ),
      ),
    ));
  }

  ratings() {
    var firebaseUser = FirebaseAuth.instance.currentUser;

    FirebaseFirestore.instance
        .collection('ratings')
        .doc(firebaseUser.uid)
        .get()
        .then((DocumentSnapshot documentSnapshot) {
      if (documentSnapshot.exists) {
        Map lst = documentSnapshot.get('movieList');
        if (lst.containsKey(movieId) && j < 1) {
          setState(() {
            existR = true;
            j++;
          });
        } else if (!lst.containsKey(movieId) && j < 1) {
          setState(() {
            existR = false;
            j++;
          });
        }
      } else {
        print('Document does not exist on the database');
      }
    });

    if (existR != true) {
      return showNotRate();
    } else if (existR == true) {
      return showRate();
    }
  }

  showRate() {
    var firebaseUser = FirebaseAuth.instance.currentUser.uid;

    FirebaseFirestore.instance
        .collection('ratings')
        .doc(firebaseUser)
        .get()
        .then((DocumentSnapshot documentSnapshot) {
      if (documentSnapshot.exists) {
        Map lst = documentSnapshot.get('movieList');
        if (r < 1) {
          setState(() {
            rating = lst[widget.movId].toString();
            r++;
          });
        }
      }
    });
    return (ElevatedButton(
      onPressed: () {
        customDialog(context,
            title: Text(
              getTranslated(context, "change_rating"),
              style: TextStyle(
                color: Colors.black,
                fontSize: 32,
              ),
            ),
            content: FormBuilder(
              key: _fbKey1,
              child: Column(
                children: [
                  RatingBar.builder(
                    initialRating: double.parse(rating),
                    minRating: 1,
                    direction: Axis.horizontal,
                    allowHalfRating: true,
                    itemCount: 10,
                    itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                    itemBuilder: (context, _) => Icon(
                      Icons.star,
                      color: Colors.amber,
                    ),
                    onRatingUpdate: (ratingf) {
                      setState(() {
                        newRat = ratingf;
                      });
                    },
                  ),
                  Text(
                    'You rated : $rating stars',
                    style: TextStyle(fontSize: 15),
                  ),
                  Divider(),
                  Row(
                    children: [
                      Spacer(),
                      ElevatedButton(
                          onPressed: () {
                            setState(() {
                              i = 0;
                              j = 0;
                              r = 0;
                              //rating = newRat;
                              if (_fbKey1.currentState.validate()) {
                                FirebaseFirestore.instance
                                    .collection('ratings')
                                    .doc(firebaseUser)
                                    .update({
                                  'movieList.$movieId': newRat
                                }) // <-- Updated data
                                    .then((_) => (Navigator.of(context,
                                            rootNavigator: true)
                                        .pop()));
                              }
                            });
                          },
                          style: ElevatedButton.styleFrom(
                            primary: kPrimaryColor,
                          ),
                          child: Text("Rate")),
                      SizedBox(
                        width: 20,
                      ),
                      ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            primary: kPrimaryColor,
                          ),
                          onPressed: () {
                            Navigator.of(context, rootNavigator: true).pop();
                          },
                          child: Text("Cancel")),
                      Spacer()
                    ],
                  )
                ],
              ),
            ),
            hideNeutralButton: true,
            closeOnBackPress: true);
      },
      style: ElevatedButton.styleFrom(
        primary: kPrimaryColor,
      ),
      child: Center(
        child: Row(
          children: [
            //Text(getTranslated(context, "your_rate")),
            Text(getTranslated(context, "rate") + " $rating".toString()),
            Icon(Icons.star, color: Colors.yellow),
          ],
        ),
      ),
    ));
  }

  showNotRate() {
    var firebaseUser = FirebaseAuth.instance.currentUser.uid;
    return (ElevatedButton(
      onPressed: () {
        customDialog(
          context,
          title: Text(
            getTranslated(context, "rate_movie"),
            style: TextStyle(
              color: Colors.black,
              fontSize: 32,
            ),
          ),
          content: FormBuilder(
            key: _fbKey,
            child: Column(
              children: [
                Column(
                  children: [
                    RatingBar.builder(
                      initialRating: double.parse(newRat.toString()),
                      minRating: 1,
                      direction: Axis.horizontal,
                      allowHalfRating: true,
                      itemCount: 10,
                      itemPadding: EdgeInsets.symmetric(horizontal: 4.0),
                      itemBuilder: (context, _) => Icon(
                        Icons.star,
                        color: Colors.amber,
                      ),
                      onRatingUpdate: (ratingf) {
                        setState(() {
                          newRat = ratingf;
                        });
                      },
                    ),
                  ],
                ),
                Divider(),
                Row(
                  children: [
                    Spacer(),
                    ElevatedButton(
                        onPressed: () {
                          setState(() {
                            i = 0;
                            j = 0;
                            r = 0;
                            //rating = newRat.toString();
                            if (_fbKey.currentState.validate()) {
                              FirebaseFirestore.instance
                                  .collection('ratings')
                                  .doc(firebaseUser)
                                  .update({
                                'movieList.$movieId': newRat
                              }) // <-- Updated data
                                  .then((_) => (Navigator.of(context,
                                          rootNavigator: true)
                                      .pop()));
                            }
                          });
                        },
                        style: ElevatedButton.styleFrom(
                          primary: kPrimaryColor,
                        ),
                        child: Text("Set")),
                    SizedBox(
                      width: 20,
                    ),
                    ElevatedButton(
                        style: ElevatedButton.styleFrom(
                          primary: kPrimaryColor,
                        ),
                        onPressed: () {
                          Navigator.of(context, rootNavigator: true).pop();
                        },
                        child: Text("Cancel")),
                    Spacer()
                  ],
                )
              ],
            ),
          ),
          hideNeutralButton: true,
          closeOnBackPress: true,
        );
      },
      style: ElevatedButton.styleFrom(
        primary: kPrimaryColor,
      ),
      child: Center(
        child: Row(
          children: [
            Text(getTranslated(context, "rate") + " "),
            Icon(
              Icons.star,
              color: Colors.white,
            ),
          ],
        ),
      ),
    ));
  }

  post() {
    List likes = [];
    return (Row(
      children: [
        Icon(Icons.person, color: kPrimaryColor),
        Flexible(
          child: Card(
            child: Container(
              //width: MediaQuery.of(context).size.width/1.7,
              child: Padding(
                padding: EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: TextFormField(
                        controller: myController,
                        maxLength: 150,
                        decoration: new InputDecoration(
                          border: new OutlineInputBorder(
                              borderSide: new BorderSide(color: Colors.teal)),
                          //helperText: 'Keep it short.',
                          labelText: getTranslated(context, "post_comment"),
                          prefixText: ' ',
                        ),
                      ),
                    ),
                    Row(
                      children: [
                        Spacer(),
                        ElevatedButton(
                          onPressed: () {
                            if (myController.text == '') {
                            } else {
                              FirebaseFirestore.instance
                                  .collection('comments')
                                  .doc()
                                  .set({
                                'userId': inputData(),
                                'comment': myController.text,
                                'commentAt': DateTime.now(),
                                'pID': 'null',
                                'movieId': movieId,
                                'likes': likes,
                              }).then((value) => myController.clear());
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            primary: kPrimaryColor,
                          ),
                          child: Text(getTranslated(context, "comment"),
                              style: TextStyle(color: Colors.white)),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    ));
  }

  comment(String userId, Timestamp time, String comment, String docId,
      List people, BuildContext bc3) {
    List likes = [];
    return (Row(
      children: [
        Icon(Icons.person, color: kPrimaryColor),
        Flexible(
          child: Card(
            elevation: 6,
            shadowColor: kPrimaryColor,
            color: kDarkBlackColor,
            child: Container(
              //width: MediaQuery.of(context).size.width/1.7,
              child: Padding(
                padding: EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    Row(
                      children: <Widget>[
                        StreamBuilder<DocumentSnapshot>(
                            stream: FirebaseFirestore.instance
                                .collection('users')
                                .doc(userId)
                                .snapshots(),
                            builder: (context, snapshot) {
                              if (!snapshot.hasData) {
                                return new Text("Loading");
                              }
                              return Container(
                                width: MediaQuery.of(context).size.width / 2,
                                child: Row(
                                  children: [
                                    Text(
                                      snapshot.data['fname'] +
                                          " " +
                                          snapshot.data['lname'] +
                                          "    ",
                                      maxLines: 2,
                                      style: TextStyle(
                                          color: kPrimaryColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      "• " + readTimestamp(time, bc3),
                                      style: TextStyle(
                                          fontSize: 8, color: kBodyTextColor),
                                    ),
                                  ],
                                ),
                              );
                            }),
                        Spacer(),
                        inputData() == userId
                            ? IconButton(
                                icon: Icon(Icons.delete),
                                color: kPrimaryColor,
                                onPressed: () {
                                  showAnimatedDialog(
                                    context: context,
                                    barrierDismissible: true,
                                    builder: (BuildContext context) {
                                      return ClassicGeneralDialogWidget(
                                        titleText: 'Alert!',
                                        contentText:
                                            'Are you sure you want to delete your comment?',
                                        onPositiveClick: () {
                                          FirebaseFirestore.instance
                                              .collection('comments')
                                              .doc(docId)
                                              .update({'comment': null}).then(
                                                  (_) => (Navigator.of(context,
                                                          rootNavigator: true)
                                                      .pop()));
                                        },
                                        onNegativeClick: () {
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .pop();
                                        },
                                      );
                                    },
                                    animationType: DialogTransitionType.size,
                                    curve: Curves.fastOutSlowIn,
                                    duration: Duration(seconds: 1),
                                  );
                                },
                              )
                            : Text(''),
                      ],
                    ),
                    StreamBuilder(
                        stream: FirebaseFirestore.instance
                            .collection('ratings')
                            .doc(userId)
                            .snapshots(),
                        // ignore: missing_return
                        builder: (context, snapshot) {
                          if (!snapshot.hasData) {
                            return new Text("Loading");
                          } else if (snapshot.hasError) {
                            return (Align(
                                alignment: Alignment.centerLeft,
                                child: Row(
                                  children: [
                                    Container(
                                      height: 15,
                                      width: 15,
                                      child: Icon(
                                        Icons.star,
                                        color: Colors.grey,
                                        size: 13,
                                      ),
                                    ),
                                  ],
                                )));
                          } else if (snapshot.hasData) {
                            try {
                              return Align(
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    children: [
                                      Container(
                                          child: Text(
                                              snapshot
                                                  .data['movieList.$movieId'],
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.white))),
                                      Container(
                                        height: 15,
                                        width: 15,
                                        child: Icon(
                                          Icons.star,
                                          color: Colors.yellow,
                                          size: 13,
                                        ),
                                      ),
                                    ],
                                  ));
                            } catch (e) {
                              return (Align(
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    children: [
                                      Container(
                                        height: 15,
                                        width: 15,
                                        child: Icon(
                                          Icons.star,
                                          color: Colors.grey,
                                          size: 13,
                                        ),
                                      ),
                                    ],
                                  )));
                            }
                          }
                        }),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: comment == null
                          ? Text(
                              getTranslated(context, "comment_removed"),
                              style: TextStyle(color: kBodyTextColor),
                            )
                          : Text(
                              comment,
                              style: TextStyle(color: Colors.white),
                            ),
                    ),
                    Row(
                      children: [
                        people.length > 0
                            ? Row(
                                children: [
                                  Icon(Icons.thumb_up, color: Colors.blue),
                                  Text(
                                    " " +
                                        people.length.toString() +
                                        getTranslated(context, "likes"),
                                    style: TextStyle(
                                        color: kBodyTextColor,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              )
                            : Text(" "),
                        Spacer(),
                        inputData() != null
                            ? people.contains(inputData())
                                ? InkWell(
                                    child: Text(
                                      getTranslated(context, "like"),
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          color: Colors.blue,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    onTap: () {
                                      FirebaseFirestore.instance
                                          .collection("comments")
                                          .doc(docId)
                                          .update({
                                        "likes": FieldValue.arrayRemove(
                                            [inputData()])
                                      });
                                    })
                                : InkWell(
                                    child: Text(
                                      getTranslated(context, "like"),
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          color: kBodyTextColor,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    onTap: () {
                                      FirebaseFirestore.instance
                                          .collection("comments")
                                          .doc(docId)
                                          .update({
                                        "likes":
                                            FieldValue.arrayUnion([inputData()])
                                      });
                                    })
                            : Text(" "),
                        SizedBox(
                          width: 20,
                        ),
                        inputData() != null
                            ? InkWell(
                                onTap: () {
                                  customDialog(
                                    context,
                                    content: Column(
                                      children: [
                                        TextFormField(
                                          controller: myController1,
                                          maxLength: 150,
                                          decoration: new InputDecoration(
                                            border: new OutlineInputBorder(
                                                borderSide: new BorderSide(
                                                    color: Colors.teal)),
                                            labelText:
                                                getTranslated(context, "reply"),
                                            prefixText: ' ',
                                          ),
                                        ),
                                        Divider(),
                                      ],
                                    ),
                                    positiveButtonText:
                                        getTranslated(context, "reply"),
                                    positiveButtonAction: () {
                                      if (myController1.text == '') {
                                      } else {
                                        FirebaseFirestore.instance
                                            .collection('comments')
                                            .doc()
                                            .set({
                                              'userId': inputData(),
                                              'comment': myController1.text,
                                              'commentAt': DateTime.now(),
                                              'pID': docId,
                                              'movieId': movieId,
                                              'likes': likes,
                                            })
                                            .then((value) =>
                                                myController1.clear())
                                            .then((_) => (Navigator.of(context,
                                                    rootNavigator: true)
                                                .pop()));
                                      }
                                    },
                                    neutralButtonAction: () {
                                      Navigator.of(context, rootNavigator: true)
                                          .pop();
                                    },
                                    hideNeutralButton: false,
                                    closeOnBackPress: true,
                                  );
                                },
                                child: Text(
                                  getTranslated(context, "reply"),
                                  textAlign: TextAlign.right,
                                  style: TextStyle(
                                      color: Colors.blue,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold),
                                ),
                              )
                            : Text(
                                getTranslated(
                                    context, "sign_in_to_reply_to_comment"),
                                style: TextStyle(
                                    color: kBodyTextColor, fontSize: 8),
                              )
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    ));
  }

  innerComment(String userId, Timestamp time, String comment, String docId,
      List people, BuildContext bc2) {
    List likes = [];
    return (Row(
      children: [
        SizedBox(width: 30),
        Icon(Icons.person, color: kPrimaryColor),
        Flexible(
          child: Card(
            color: kDarkBlackColor,
            child: Container(
              //width: MediaQuery.of(context).size.width/1.7,
              child: Padding(
                padding: EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    Row(
                      children: <Widget>[
                        StreamBuilder<DocumentSnapshot>(
                            stream: FirebaseFirestore.instance
                                .collection('users')
                                .doc(userId)
                                .snapshots(),
                            builder: (context, snapshot) {
                              if (!snapshot.hasData) {
                                return new Text("Loading");
                              }
                              return Container(
                                width: MediaQuery.of(context).size.width / 2,
                                child: Row(
                                  children: [
                                    Text(
                                      snapshot.data['fname'] +
                                          " " +
                                          snapshot.data['lname'] +
                                          "    ",
                                      maxLines: 2,
                                      style: TextStyle(
                                          color: kPrimaryColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      "• " + readTimestamp(time, bc2),
                                      style: TextStyle(
                                          fontSize: 8, color: kBodyTextColor),
                                    ),
                                  ],
                                ),
                              );
                            }),
                        Spacer(),
                        inputData() == userId
                            ? IconButton(
                                icon: Icon(Icons.delete),
                                color: kPrimaryColor,
                                onPressed: () {
                                  showAnimatedDialog(
                                    context: context,
                                    barrierDismissible: true,
                                    builder: (BuildContext context) {
                                      return ClassicGeneralDialogWidget(
                                        titleText: 'Alert!',
                                        contentText:
                                            'Are you sure you want to delete your comment?',
                                        onPositiveClick: () {
                                          FirebaseFirestore.instance
                                              .collection('comments')
                                              .doc(docId)
                                              .update({'comment': null}).then(
                                                  (_) => (Navigator.of(context,
                                                          rootNavigator: true)
                                                      .pop()));
                                        },
                                        onNegativeClick: () {
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .pop();
                                        },
                                      );
                                    },
                                    animationType: DialogTransitionType.size,
                                    curve: Curves.fastOutSlowIn,
                                    duration: Duration(seconds: 1),
                                  );
                                },
                              )
                            : Text(''),
                      ],
                    ),
                    StreamBuilder(
                        stream: FirebaseFirestore.instance
                            .collection('ratings')
                            .doc(userId)
                            .snapshots(),
                        // ignore: missing_return
                        builder: (context, snapshot) {
                          if (!snapshot.hasData) {
                            return new Text("Loading");
                          } else if (snapshot.hasError) {
                            return (Align(
                                alignment: Alignment.centerLeft,
                                child: Row(
                                  children: [
                                    Container(
                                      height: 15,
                                      width: 15,
                                      child: Icon(
                                        Icons.star,
                                        color: Colors.grey,
                                        size: 13,
                                      ),
                                    ),
                                  ],
                                )));
                          } else if (snapshot.hasData) {
                            try {
                              return Align(
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    children: [
                                      Container(
                                          child: Text(
                                              snapshot
                                                  .data['movieList.$movieId'],
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.white))),
                                      Container(
                                        height: 15,
                                        width: 15,
                                        child: Icon(
                                          Icons.star,
                                          color: Colors.yellow,
                                          size: 13,
                                        ),
                                      ),
                                    ],
                                  ));
                            } catch (e) {
                              return (Align(
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    children: [
                                      Container(
                                        height: 15,
                                        width: 15,
                                        child: Icon(
                                          Icons.star,
                                          color: Colors.grey,
                                          size: 13,
                                        ),
                                      ),
                                    ],
                                  )));
                            }
                          }
                        }),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: comment == null
                          ? Text(
                              getTranslated(context, "comment_removed"),
                              style: TextStyle(color: kBodyTextColor),
                            )
                          : Text(
                              comment,
                              style: TextStyle(color: Colors.white),
                            ),
                    ),
                    Row(
                      children: [
                        people.length > 0
                            ? Row(
                                children: [
                                  Icon(Icons.thumb_up, color: Colors.blue),
                                  Text(
                                    " " +
                                        people.length.toString() +
                                        getTranslated(context, "likes"),
                                    style: TextStyle(
                                        color: kBodyTextColor,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              )
                            : Text(" "),
                        Spacer(),
                        inputData() != null
                            ? people.contains(inputData())
                                ? InkWell(
                                    child: Text(
                                      getTranslated(context, "like"),
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          color: Colors.blue,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    onTap: () {
                                      FirebaseFirestore.instance
                                          .collection("comments")
                                          .doc(docId)
                                          .update({
                                        "likes": FieldValue.arrayRemove(
                                            [inputData()])
                                      });
                                    })
                                : InkWell(
                                    child: Text(
                                      getTranslated(context, "like"),
                                      textAlign: TextAlign.right,
                                      style: TextStyle(
                                          color: kBodyTextColor,
                                          fontSize: 10,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    onTap: () {
                                      FirebaseFirestore.instance
                                          .collection("comments")
                                          .doc(docId)
                                          .update({
                                        "likes":
                                            FieldValue.arrayUnion([inputData()])
                                      });
                                    })
                            : Text(" "),
                        SizedBox(
                          width: 20,
                        ),
                        inputData() != null
                            ? InkWell(
                                onTap: () {
                                  customDialog(
                                    context,
                                    content: Column(
                                      children: [
                                        TextFormField(
                                          controller: myController2,
                                          maxLength: 150,
                                          decoration: new InputDecoration(
                                            border: new OutlineInputBorder(
                                                borderSide: new BorderSide(
                                                    color: Colors.teal)),
                                            labelText:
                                                getTranslated(context, "reply"),
                                            prefixText: ' ',
                                          ),
                                        ),
                                        Divider(),
                                      ],
                                    ),
                                    positiveButtonText:
                                        getTranslated(context, "reply"),
                                    positiveButtonAction: () {
                                      if (myController2.text == '') {
                                      } else {
                                        FirebaseFirestore.instance
                                            .collection('comments')
                                            .doc()
                                            .set({
                                              'userId': inputData(),
                                              'comment': myController2.text,
                                              'commentAt': DateTime.now(),
                                              'pID': docId,
                                              'movieId': movieId,
                                              'likes': likes,
                                            })
                                            .then((value) =>
                                                myController2.clear())
                                            .then((_) => (Navigator.of(context,
                                                    rootNavigator: true)
                                                .pop()));
                                      }
                                    },
                                    neutralButtonAction: () {
                                      Navigator.of(context, rootNavigator: true)
                                          .pop();
                                    },
                                    hideNeutralButton: false,
                                    closeOnBackPress: true,
                                  );
                                },
                                child: Text(
                                  getTranslated(context, "reply"),
                                  textAlign: TextAlign.right,
                                  style: TextStyle(
                                      color: Colors.blue,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold),
                                ),
                              )
                            : Text(" ")
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    ));
  }

  thirdComment(String userId, Timestamp time, String comment, String docId,
      List people, BuildContext bc1) {
    return (Row(
      children: [
        SizedBox(width: 60),
        Icon(Icons.person, color: kPrimaryColor),
        Flexible(
          child: Card(
            color: kDarkBlackColor,
            child: Container(
              //width: MediaQuery.of(context).size.width/1.7,
              child: Padding(
                padding: EdgeInsets.all(12.0),
                child: Column(
                  children: [
                    Row(
                      children: <Widget>[
                        StreamBuilder<DocumentSnapshot>(
                            stream: FirebaseFirestore.instance
                                .collection('users')
                                .doc(userId)
                                .snapshots(),
                            builder: (context, snapshot) {
                              if (!snapshot.hasData) {
                                return new Text("Loading");
                              }
                              return Container(
                                width: MediaQuery.of(context).size.width / 2,
                                child: Row(
                                  children: [
                                    Text(
                                      snapshot.data['fname'] +
                                          " " +
                                          snapshot.data['lname'] +
                                          "    ",
                                      maxLines: 2,
                                      style: TextStyle(
                                          color: kPrimaryColor,
                                          fontWeight: FontWeight.bold),
                                    ),
                                    Text(
                                      "• " + readTimestamp(time, bc1),
                                      style: TextStyle(
                                          fontSize: 8, color: kBodyTextColor),
                                    ),
                                  ],
                                ),
                              );
                            }),
                        Spacer(),
                        inputData() == userId
                            ? IconButton(
                                icon: Icon(Icons.delete),
                                color: kPrimaryColor,
                                onPressed: () {
                                  showAnimatedDialog(
                                    context: context,
                                    barrierDismissible: true,
                                    builder: (BuildContext context) {
                                      return ClassicGeneralDialogWidget(
                                        titleText: 'Alert!',
                                        contentText:
                                            'Are you sure you want to delete your comment?',
                                        onPositiveClick: () {
                                          FirebaseFirestore.instance
                                              .collection('comments')
                                              .doc(docId)
                                              .update({'comment': null}).then(
                                                  (_) => (Navigator.of(context,
                                                          rootNavigator: true)
                                                      .pop()));
                                        },
                                        onNegativeClick: () {
                                          Navigator.of(context,
                                                  rootNavigator: true)
                                              .pop();
                                        },
                                      );
                                    },
                                    animationType: DialogTransitionType.size,
                                    curve: Curves.fastOutSlowIn,
                                    duration: Duration(seconds: 1),
                                  );
                                },
                              )
                            : Text(''),
                      ],
                    ),
                    StreamBuilder(
                        stream: FirebaseFirestore.instance
                            .collection('ratings')
                            .doc(userId)
                            .snapshots(),
                        // ignore: missing_return
                        builder: (context, snapshot) {
                          if (!snapshot.hasData) {
                            return new Text("Loading");
                          } else if (snapshot.hasError) {
                            return (Align(
                                alignment: Alignment.centerLeft,
                                child: Row(
                                  children: [
                                    Container(
                                      height: 15,
                                      width: 15,
                                      child: Icon(
                                        Icons.star,
                                        color: Colors.grey,
                                        size: 13,
                                      ),
                                    ),
                                  ],
                                )));
                          } else if (snapshot.hasData) {
                            try {
                              return Align(
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    children: [
                                      Container(
                                          child: Text(
                                              snapshot
                                                  .data['movieList.$movieId'],
                                              style: TextStyle(
                                                  fontSize: 13,
                                                  color: Colors.white))),
                                      Container(
                                        height: 15,
                                        width: 15,
                                        child: Icon(
                                          Icons.star,
                                          color: Colors.yellow,
                                          size: 13,
                                        ),
                                      ),
                                    ],
                                  ));
                            } catch (e) {
                              return (Align(
                                  alignment: Alignment.centerLeft,
                                  child: Row(
                                    children: [
                                      Container(
                                        height: 15,
                                        width: 15,
                                        child: Icon(
                                          Icons.star,
                                          color: Colors.grey,
                                          size: 13,
                                        ),
                                      ),
                                    ],
                                  )));
                            }
                          }
                        }),
                    Container(
                      width: MediaQuery.of(context).size.width,
                      child: comment == null
                          ? Text(
                              getTranslated(context, "comment_removed"),
                              style: TextStyle(color: kBodyTextColor),
                            )
                          : Text(
                              comment,
                              style: TextStyle(color: Colors.white),
                            ),
                    ),
                    Row(children: [
                      people.length > 0
                          ? Row(
                              children: [
                                Icon(Icons.thumb_up, color: Colors.blue),
                                Text(
                                  " " +
                                      people.length.toString() +
                                      getTranslated(context, "likes"),
                                  style: TextStyle(
                                      color: kBodyTextColor,
                                      fontSize: 10,
                                      fontWeight: FontWeight.bold),
                                ),
                              ],
                            )
                          : Text(" "),
                      Spacer(),
                      inputData() != null
                          ? people.contains(inputData())
                              ? InkWell(
                                  child: Text(
                                    getTranslated(context, "like"),
                                    textAlign: TextAlign.right,
                                    style: TextStyle(
                                        color: Colors.blue,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  onTap: () {
                                    FirebaseFirestore.instance
                                        .collection("comments")
                                        .doc(docId)
                                        .update({
                                      "likes":
                                          FieldValue.arrayRemove([inputData()])
                                    });
                                  })
                              : InkWell(
                                  child: Text(
                                    getTranslated(context, "like"),
                                    textAlign: TextAlign.right,
                                    style: TextStyle(
                                        color: kBodyTextColor,
                                        fontSize: 10,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  onTap: () {
                                    FirebaseFirestore.instance
                                        .collection("comments")
                                        .doc(docId)
                                        .update({
                                      "likes":
                                          FieldValue.arrayUnion([inputData()])
                                    });
                                  })
                          : Text(" "),
                    ])
                  ],
                ),
              ),
            ),
          ),
        ),
      ],
    ));
  }
}

String readTimestamp(Timestamp timestamp, BuildContext bc) {
  var now = DateTime.now();
  var format = DateFormat('HH:mm a');
  var date = timestamp;
  var diff = now.difference(date.toDate());
  var time = '';

  if (diff.inSeconds <= 0 ||
      diff.inSeconds > 0 && diff.inMinutes == 0 ||
      diff.inMinutes > 0 && diff.inHours == 0 ||
      diff.inHours > 0 && diff.inDays == 0) {
    time = format.format(date.toDate());
  } else if (diff.inDays > 0 && diff.inDays < 7) {
    if (diff.inDays == 1) {
      time = diff.inDays.toString() +
          " " +
          getTranslated(bc, "day_ago").toString();
    } else {
      time = diff.inDays.toString() +
          " " +
          getTranslated(bc, "days_ago").toString();
    }
  } else {
    if (diff.inDays == 7) {
      time = (diff.inDays / 7).floor().toString() +
          getTranslated(bc, "week_ago").toString();
    } else {
      time = (diff.inDays / 7).floor().toString() +
          getTranslated(bc, "weeks_ago").toString();
    }
  }

  return time;
}
