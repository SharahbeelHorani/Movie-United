import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:movie_united/localization/language_constants.dart';
import 'package:movie_united/pages/tvPreview.dart';
import 'Components/footer.dart';

class TopTvSeries extends StatefulWidget {
  @override
  _TopTvSeriesState createState() => _TopTvSeriesState();
}

class _TopTvSeriesState extends State<TopTvSeries> {
  DocumentSnapshot lasts;
  final db = FirebaseFirestore.instance;


  int current = 0;
  int size = 0;
  List<Stream> stbatch = [
    (FirebaseFirestore.instance
        .collection("tvSeries")
        .orderBy("tvRating", descending: true)
        .limit(10)
        .snapshots())
  ];
  var lastRef;
  bool lastDoc = false;
  @override
  void initState() {
    FirebaseFirestore.instance
        .collection('tvSeries')
        .orderBy('tvRating', descending: false)
        .limit(1)
        .get()
        .then((QuerySnapshot snapshot) => {
              snapshot.docs.forEach((element) {
                lastRef = element.reference.id;
              })
            });
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        width: double.infinity,
        color: kFullBlack,
        child: SafeArea(
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(kDefaultPadding/2),
                constraints: BoxConstraints(maxWidth: kMaxWidth),
                child: Column(
                  children: [
                    SizedBox(height: kDefaultPadding * 2),
                    Row(
                      children: [
                        Text(
                          getTranslated(context, "top_tv_series"),
                          style: TextStyle(
                              color: kBgColor,
                              fontSize: 25,
                              fontWeight: FontWeight.w900),
                        ),
                      ],
                    ),
                    SizedBox(height: kDefaultPadding * 2),
                    Container(
                      child: ListView(
                        shrinkWrap: true,
                        physics: ClampingScrollPhysics(),
                        padding: const EdgeInsets.all(5),
                        children: [
                          Container(
                            color: kDarkBlackColor,
                            child: StreamBuilder<QuerySnapshot>(
                              stream: stbatch[current],
                              // ignore: missing_return
                              builder: (context, snapshot) {
                                if (!snapshot.hasData ||
                                    snapshot.data.docs == null) {
                                  print("no Data");
                                  return LinearProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(kPrimaryColor),);
                                } else if (snapshot.data.docs.length == 0) {
                                  lastDoc = true;
                                  return Container( height: 30,
                                    child: Center(child: Text(getTranslated(context, "end_reached"), style: TextStyle(fontSize: 20,color: Colors.white),)),
                                  );
                                } else if (snapshot.data.docs.length > 0) {
                                  lasts = snapshot
                                      .data.docs[snapshot.data.docs.length - 1];
                                  print("Has Data");
                                  return DataTable(
                                    columnSpacing: 0,
                                    showCheckboxColumn: false,
                                    dataRowHeight: 80,
                                    columns: [
                                      DataColumn(
                                          label: Text(getTranslated(context, "tv_series_title"),
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: kBgColor,
                                                  fontWeight:
                                                  FontWeight.bold))),

                                      DataColumn(
                                          label: Text(getTranslated(context, "rating"),
                                              style: TextStyle(
                                                  fontSize: 14,
                                                  color: kBgColor,
                                                  fontWeight:
                                                  FontWeight.bold))),

                                    ],
                                    rows:
                                    _buildList(context, snapshot.data.docs),
                                  );
                                }
                                else
                                  return Container();
                              },
                            ),
                          ),
                          Container(
                            color: kDarkBlackColor,
                            height: 60,
                            width: 20,
                            padding: const EdgeInsets.all(16),
                            child: Row(
                              children: [
                                Spacer(),
                                current != 0
                                    ? InkWell(
                                        child: Icon(Icons.arrow_left,
                                            color: kPrimaryColor, size: 40),
                                        onTap: () {
                                          setState(() {
                                            current = current - 1;
                                            lastDoc = false;
                                          });
                                        })
                                    : InkWell(
                                        child: Icon(Icons.arrow_left,
                                            color: kBodyTextColor, size: 40),
                                        onTap: () {}),
                                Text(
                                  getTranslated(context, "page") +" " + (current + 1).toString(),
                                  style: TextStyle(color: Colors.white),
                                ),
                                lastDoc != true
                                    ? InkWell(
                                        child: Icon(Icons.arrow_right,
                                            color: kPrimaryColor, size: 40),
                                        onTap: () {
                                          setState(() {
                                            if (current == size) {
                                              stbatch.add(FirebaseFirestore
                                                  .instance
                                                  .collection('tvSeries')
                                                  .orderBy('tvRating',
                                                      descending: true)
                                                  .startAfterDocument(lasts)
                                                  .limit(10)
                                                  .snapshots());
                                              current = current + 1;
                                              size = size + 1;
                                            } else {
                                              current = current + 1;
                                            }
                                          });
                                        },
                                      )
                                    : InkWell(
                                        child: Icon(Icons.arrow_right,
                                            color: kBodyTextColor, size: 40),
                                        onTap: () {},
                                      ),
                                Spacer(),
                              ],
                            ),
                          )
                        ],
                      ),
                    ),
                    SizedBox(height: kDefaultPadding * 4),
                    FooterWeb(),
                  ],
                ),
              )
            ],
          ),
        ),
      ),
    );
  }

  List<DataRow> _buildList(
      BuildContext context, List<DocumentSnapshot> snapshot) {
    print("object");
    return snapshot.map((data) => _buildListItem(context, data)).toList();
  }

  DataRow _buildListItem(BuildContext context, DocumentSnapshot data) {
    final record = Record.fromSnapshot(data);
    if (data.id == lastRef) {
      lastDoc = true;
    }
    print("last");
    return DataRow(
      cells: [
        DataCell(
          Container(
            width: MediaQuery.of(context).size.width/2,
            child: ListTile(
              contentPadding: EdgeInsets.symmetric(vertical:-10, horizontal: -10),
              leading: Container(
                child: StreamBuilder(
                  stream: record.imgURL().asStream(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {
                      return CircularProgressIndicator(valueColor: AlwaysStoppedAnimation<Color>(kPrimaryColor),);
                    }
                    return Container(
                        width: 40.5, height: 60, child: Image.network(snapshot.data.toString(),fit: BoxFit.cover));
                  },
                ),
              ),
              title: Text(
                record.tvName,
                style: TextStyle(
                  color: Colors.white, fontSize: 12),
              ),
              subtitle: Text(
                record.tvGenre,
                style: TextStyle(
                  color: Colors.grey, fontSize: 10),
              ),


            ),
          ),
        ),
        DataCell(Row(
          children: [
            Icon(Icons.star, color: Colors.yellow, size: 14),
            Text( " " +
                record.tvRating.toString(),
              style: TextStyle(
                color: kBgColor, fontSize: 12
              ),
            ),
          ],
        )),

      ],
        onSelectChanged: (newValue) {
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => TvPreview(tvId: data.id)),);
        }
    );
  }
}

class Record {
  final String tvName;
  final String tvGenre;
  final num tvRating;
  final String tvImg;
  final DocumentReference reference;

  Future imgURL() {
    return FirebaseStorage.instance.ref().
    child(tvImg).getDownloadURL();
  }

  Record.fromMap(Map<String, dynamic> map, {@required this.reference})
      : assert(map['tvName'] != null),
        assert(map['tvGenre'] != null),
        assert(map['tvRating'] != null),
        assert(map['tvImg'] != null),
        tvName = map['tvName'],
        tvGenre = map['tvGenre'].join(", "),
        tvRating = map['tvRating'],
        tvImg = map['tvImg'];

  Record.fromSnapshot(DocumentSnapshot snapshot)
      : this.fromMap(snapshot.data() as Map<String, dynamic>, reference: snapshot.reference);

  @override
  String toString() => "Record<$tvName:$tvRating:$tvGenre>";
}
