import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:flutter_animated_dialog/flutter_animated_dialog.dart';
import 'package:flutter_form_builder/flutter_form_builder.dart';
import 'package:get/get.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:movie_united/localization/language_constants.dart';
import 'Components/footer.dart';

class Profile extends StatefulWidget {
  const Profile({Key key}) : super(key: key);

  @override
  _ProfileState createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {
  TextEditingController password = TextEditingController();
  TextEditingController password1 = TextEditingController();
  final FirebaseAuth auth = FirebaseAuth.instance;
  inputData() {
    String uid = "";
    final User user = auth.currentUser;
    if (user != null) {
      return (uid = user.uid);
    } else
      return (uid = "No");
  }


  final _fbKey = GlobalKey<FormBuilderState>();
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Container(
        width: double.infinity,
        color: kFullBlack,
        child: SafeArea(
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(kDefaultPadding),
                constraints: BoxConstraints(maxWidth: kMaxWidth),
                child: FormBuilder(
                  key: _fbKey,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      new StreamBuilder<DocumentSnapshot>(
                        stream: FirebaseFirestore.instance
                            .collection('users')
                            .doc(inputData())
                            .snapshots(),
                        builder: (context, snapshot) {
                          if (!snapshot.hasData) {
                            return new Text("Loading");
                          }
                          var userDocument = snapshot.data;
                          String email = userDocument["email"];
                          String lname = userDocument["lname"];
                          String fname = userDocument["fname"];
                          return (Column(
                            children: <Widget>[
                              SizedBox(height: kDefaultPadding * 2),
                              Row(
                                children: [
                                  Spacer(),
                                  CircleAvatar(
                                      radius: 65,
                                      backgroundColor: kBodyTextColor,
                                      child: Icon(
                                        Icons.person_rounded,
                                        color: kPrimaryColor,
                                        size: 100,
                                      )),
                                  Spacer()
                                ],
                              ),
                              SizedBox(height: kDefaultPadding * 2),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 16),
                                child: Row(
                                  children: [
                                    Text(
                                     getTranslated(context, "personal_details"),
                                      style: TextStyle(
                                          color: kPrimaryColor,
                                          fontSize: 30,
                                          fontWeight: FontWeight.w900),
                                    ),
                                    Spacer(),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 16),
                                child: Row(
                                  children: [
                                    Container(
                                      width: MediaQuery.of(context).size.width/2,
                                      child: FormBuilderTextField(
                                        name: getTranslated(context, "first_name"),
                                        initialValue: fname,
                                        validator:
                                        FormBuilderValidators.required(
                                            context),
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(),
                                          filled: true,
                                          fillColor: Colors.white,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 16),
                                child: Row(
                                  children: [
                                    Container(
                                      width: MediaQuery.of(context).size.width/2,
                                      child: FormBuilderTextField(
                                        initialValue: lname,
                                        //maxLength: 250,
                                        name: getTranslated(context, "last_name"),
                                        validator:
                                        FormBuilderValidators.required(
                                            context),
                                        decoration: InputDecoration(
                                          border: OutlineInputBorder(),
                                          filled: true,
                                          fillColor: Colors.white,
                                        ),
                                      ),
                                    ),
                                    Spacer(),
                                  ],
                                ),
                              ),
                              SizedBox(height: kDefaultPadding * 2),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 16),
                                child: Row(
                                  children: [
                                    Text(
                                      getTranslated(context, "account_details"),
                                      style: TextStyle(
                                          color: kPrimaryColor,
                                          fontSize: 30,
                                          fontWeight: FontWeight.w900),
                                    ),
                                    Spacer(),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 16),
                                child: FormBuilderTextField(
                                  initialValue: email,
                                  //maxLength: 250,
                                  name: getTranslated(context, "email"),
                                  readOnly: true,
                                  validator:
                                  FormBuilderValidators.required(context),
                                  decoration: InputDecoration(
                                    border: OutlineInputBorder(),
                                    filled: true,
                                    fillColor: Colors.white,
                                  ),
                                ),
                              ),
                              SizedBox(height: kDefaultPadding * 2),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 16),
                                child: Row(
                                  children: [
                                    Text(
                                      getTranslated(context, "change_password"),
                                      style: TextStyle(
                                          color: kPrimaryColor,
                                          fontSize: 30,
                                          fontWeight: FontWeight.w900),
                                    ),
                                    Spacer(),
                                  ],
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 16),
                                child: FormBuilderTextField(
                                  //maxLength: 250,
                                  name: "password",
                                  controller: password,
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      filled: true,
                                      fillColor: Colors.white,
                                      labelText: getTranslated(context, "new_password")),
                                  obscureText: true,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 16),
                                child: FormBuilderTextField(
                                  //maxLength: 250,
                                  name: "password1",
                                  controller: password1,
                                  // ignore: missing_return
                                  validator: (value) {
                                    if (password.text != password1.text) {
                                      return getTranslated(context, "Password_does_not_match");
                                    }
                                  },
                                  decoration: InputDecoration(
                                      border: OutlineInputBorder(),
                                      filled: true,
                                      fillColor: Colors.white,
                                      labelText: getTranslated(context, "please_re_enter_password")),
                                  obscureText: true,
                                ),
                              ),
                              Padding(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 8, vertical: 16),
                                child: ElevatedButton(
                                  onPressed: () {
                                    if (_fbKey.currentState.saveAndValidate()) {
                                      showAnimatedDialog(
                                        context: context,
                                        barrierDismissible: true,
                                        builder: (BuildContext context) {
                                          return ClassicGeneralDialogWidget(
                                            titleText: getTranslated(context, "confirmation"),
                                            contentText:
                                            getTranslated(context, "are_you_sure_you_want_to_update_your_profile"),
                                            onPositiveClick: () {
                                              FirebaseFirestore.instance
                                                  .collection('users')
                                                  .doc(inputData())
                                                  .update({
                                                'fname': _fbKey.currentState
                                                    .value['fname'],
                                                'lname': _fbKey.currentState
                                                    .value['lname'],
                                              }).then((value) {
                                                if(password.text.length > 0)
                                                {
                                                  User userReq = auth.currentUser;
                                                  userReq.updatePassword(_fbKey.currentState.value['password1'].toString());
                                                }
                                              })
                                                  .then((_) => _fbKey
                                                  .currentState
                                                  .reset())
                                                  .then((_) =>
                                              (Navigator.of(context)
                                                  .pop()));
                                            },
                                            onNegativeClick: () {
                                              Navigator.of(context).pop();
                                            },
                                          );
                                        },
                                        animationType:
                                        DialogTransitionType.size,
                                        curve: Curves.fastOutSlowIn,
                                        duration: Duration(seconds: 1),
                                      );
                                    }
                                  },
                                  style: ElevatedButton.styleFrom(
                                    primary: kPrimaryColor,
                                    padding: EdgeInsets.symmetric(
                                      horizontal: kDefaultPadding * 4.5,
                                      vertical: kDefaultPadding,
                                    ),
                                  ),
                                  child: Text(getTranslated(context, "update_profile")),
                                ),
                              ),
                            ],
                          ));
                        },
                      ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: kDefaultPadding * 2),
              FooterWeb(),
            ],
          ),
        ),
      ),
    );
  }
}
