import 'dart:async';
import 'dart:math';
import 'dart:ui';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:movie_united/localization/language_constants.dart';
import 'package:movie_united/pages/preview.dart';
import 'package:movie_united/pages/tvPreview.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

import 'Components/footer.dart';
import 'Components/news_section.dart';

class Home extends StatefulWidget {
  const Home({Key key}) : super(key: key);

  @override
  _HomeState createState() => _HomeState();
}

class _HomeState extends State<Home> {
  Stream slides;

  Stream _queryDb() => slides = FirebaseFirestore.instance
      .collection('movies')
      .orderBy('dateAdded', descending: true)
      .limit(5)
      .snapshots()
      .map((list) => list.docs.map((doc) => doc.data()));

  double pageOffset = 0;
  int _currentPage = 0;
  @override
  void initState() {
    _queryDb();
    Timer.periodic(Duration(seconds: 5), (Timer timer) async {
      if (_currentPage < 5) {
        _currentPage++;
      } else {
        _currentPage = 0;
      }
      if (controller.hasClients) {
        await controller.animateToPage(
          _currentPage,
          duration: Duration(milliseconds: 350),
          curve: Curves.easeIn,
        );
      }
    });
    super.initState();
  }

  final PageController controller = PageController(initialPage: 0);
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
        child: Container(
      width: double.infinity,
      color: kFullBlack,
      child: SafeArea(
          child: Column(
        children: [
          Container(
            padding: EdgeInsets.all(kDefaultPadding / 2),
            constraints: BoxConstraints(maxWidth: kMaxWidth),
            child: Column(
              children: [
                SizedBox(
                  height: kDefaultPadding,
                ),
                SizedBox(
                  width: MediaQuery.of(context).size.width / 1,
                  height: MediaQuery.of(context).size.width / 2,
                  child: StreamBuilder(
                    stream: slides,
                    // ignore: missing_return
                    builder: (context, AsyncSnapshot snap) {
                      if (snap.hasError) {
                        return CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation<Color>(kPrimaryColor),
                        );
                      } else if (!snap.hasData ||
                          snap.data == null ||
                          snap.connectionState == ConnectionState.waiting) {
                        return CircularProgressIndicator(
                          valueColor:
                              AlwaysStoppedAnimation<Color>(kPrimaryColor),
                        );
                      } else if (snap.data != null && snap != null) {
                        List slideList = snap.data.toList();
                        return PageView.builder(
                            controller: controller,
                            itemCount: slideList.length,
                            itemBuilder: (context, int index) {
                              return _buildStoryPage(slideList[index], index);
                            });
                      }
                      return (Container());
                    },
                  ),
                ),
                SizedBox(height: kDefaultPadding),
                SmoothPageIndicator(
                    controller: controller,
                    count: 5,
                    effect: WormEffect(
                      activeDotColor: kPrimaryColor,
                      dotWidth: 12,
                      dotHeight: 12,
                    )),
                SizedBox(height: kDefaultPadding * 3),
                Row(
                  children: [
                    Text(
                      getTranslated(context, "latest_release"),
                      style: TextStyle(
                          color: kPrimaryColor,
                          fontSize: 25,
                          fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
                SizedBox(height: kDefaultPadding * 2),
                Row(
                  children: [
                    Text(
                      getTranslated(context, "last_movies"),
                      // getTranslated(context, "latest_releases") ,
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                Container(
                    margin: EdgeInsets.symmetric(vertical: 40.0),
                    height: 280,
                    width: MediaQuery.of(context).size.width / 1,
                    child: StreamBuilder<QuerySnapshot>(
                        stream: FirebaseFirestore.instance
                            .collection('movies')
                            .orderBy('dateAdded', descending: true)
                            .snapshots(),
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError)
                            return new Text('Error: ${snapshot.error}');
                          switch (snapshot.connectionState) {
                            case ConnectionState.waiting:
                              return new Text('Loading...');
                            default:
                              return new ListView(
                                scrollDirection: Axis.horizontal,
                                children: snapshot.data.docs
                                    .map((DocumentSnapshot document) {
                                  return new Container(
                                    width: 135.0,
                                    child: InkWell(
                                      child: Card(
                                        elevation: 6,
                                        shadowColor: kPrimaryColor,
                                        color: kDarkBlackColor,
                                        child: Wrap(
                                          children: <Widget>[
                                            ClipRRect(
                                              child: FutureBuilder(
                                                future: FirebaseStorage.instance
                                                    .ref()
                                                    .child(document['movieImg'])
                                                    .getDownloadURL(),
                                                builder: (context, snapshot) {
                                                  if (snapshot
                                                          .connectionState ==
                                                      ConnectionState.waiting) {
                                                    return Container(
                                                      height: 200,
                                                      child: Center(
                                                          child:
                                                              CircularProgressIndicator(
                                                        valueColor:
                                                            AlwaysStoppedAnimation<
                                                                    Color>(
                                                                kPrimaryColor),
                                                      )),
                                                    );
                                                  }
                                                  return Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(20),
                                                      ),
                                                      width: 135,
                                                      child: ClipRRect(
                                                        borderRadius:
                                                            BorderRadius.only(
                                                          topLeft:
                                                              Radius.circular(
                                                                  8),
                                                          topRight:
                                                              Radius.circular(
                                                                  8),
                                                        ),
                                                        child: Image.network(
                                                            snapshot.data
                                                                .toString(),
                                                            height: 200.0,
                                                            width: 660,
                                                            fit: BoxFit.fill),
                                                      ));
                                                },
                                              ),
                                            ),
                                            ListTile(
                                              title: Text(
                                                document['movieName'],
                                                maxLines: 3,
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 12),
                                              ),
                                              subtitle: Row(
                                                children: [
                                                  //Spacer(),
                                                  Container(
                                                      width: 12,
                                                      child: Image.asset(
                                                        'assets/images/star.png',
                                                        width: 12,
                                                      )),
                                                  Text(
                                                    " " +
                                                        document['movieRating']
                                                            .toString(),
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 12),
                                                  ),
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) =>
                                                Preview(movId: document.id),
                                          ),
                                        );
                                      },
                                    ),
                                  );
                                }).toList(),
                              );
                          }
                        })),
                SizedBox(height: kDefaultPadding * 2),
                Row(
                  children: [
                    Text(
                      getTranslated(context, "last_tv_series"),
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 16,
                      ),
                    ),
                  ],
                ),
                Container(
                    margin: EdgeInsets.symmetric(vertical: 40.0),
                    height: 280,
                    width: MediaQuery.of(context).size.width / 1,
                    child: StreamBuilder<QuerySnapshot>(
                        stream: FirebaseFirestore.instance
                            .collection('tvSeries')
                            .orderBy('dateAdded', descending: true)
                            .snapshots(),
                        builder: (BuildContext context,
                            AsyncSnapshot<QuerySnapshot> snapshot) {
                          if (snapshot.hasError)
                            return new Text('Error: ${snapshot.error}');
                          switch (snapshot.connectionState) {
                            case ConnectionState.waiting:
                              return new Text('Loading...');
                            default:
                              return new ListView(
                                scrollDirection: Axis.horizontal,
                                children: snapshot.data.docs
                                    .map((DocumentSnapshot document) {
                                  return new Container(
                                    width: 135.0,
                                    child: InkWell(
                                      child: Card(
                                        elevation: 6,
                                        shadowColor: kPrimaryColor,
                                        color: kDarkBlackColor,
                                        child: Wrap(
                                          children: <Widget>[
                                            ClipRRect(
                                              child: FutureBuilder(
                                                future: FirebaseStorage.instance
                                                    .ref()
                                                    .child(document['tvImg'])
                                                    .getDownloadURL(),
                                                builder: (context, snapshot) {
                                                  if (snapshot
                                                          .connectionState ==
                                                      ConnectionState.waiting) {
                                                    return Container(
                                                      height: 200,
                                                      child: Center(
                                                          child:
                                                              CircularProgressIndicator(
                                                        valueColor:
                                                            AlwaysStoppedAnimation<
                                                                    Color>(
                                                                kPrimaryColor),
                                                      )),
                                                    );
                                                  }
                                                  return Container(
                                                      decoration: BoxDecoration(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(20),
                                                      ),
                                                      width: 135,
                                                      child: ClipRRect(
                                                        borderRadius:
                                                            BorderRadius.only(
                                                          topLeft:
                                                              Radius.circular(
                                                                  8),
                                                          topRight:
                                                              Radius.circular(
                                                                  8),
                                                        ),
                                                        child: Image.network(
                                                            snapshot.data
                                                                .toString(),
                                                            height: 200.0,
                                                            width: 660,
                                                            fit: BoxFit.fill),
                                                      ));
                                                },
                                              ),
                                            ),
                                            ListTile(
                                              title: Text(
                                                document['tvName'],
                                                style: TextStyle(
                                                    color: Colors.white,
                                                    fontSize: 12),
                                              ),
                                              subtitle: Row(
                                                children: [
                                                  //Spacer(),
                                                  Container(
                                                      width: 12,
                                                      child: Image.asset(
                                                        'assets/images/star.png',
                                                        width: 12,
                                                      )),
                                                  Text(
                                                    " " +
                                                        document['tvRating']
                                                            .toString(),
                                                    style: TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 12),
                                                  ),
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      onTap: () {
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                            builder: (context) =>
                                                TvPreview(tvId: document.id),
                                          ),
                                        );
                                      },
                                    ),
                                  );
                                }).toList(),
                              );
                          }
                        })),
                SizedBox(height: kDefaultPadding * 4),
                Row(
                  children: [
                    Text(
                      getTranslated(context, "top_news"),
                      style: TextStyle(
                          color: kPrimaryColor,
                          fontSize: 25,
                          fontWeight: FontWeight.w900),
                    ),
                  ],
                ),
                SizedBox(height: kDefaultPadding * 2),
                NewsSection(), //IN COM
                SizedBox(
                    height: kDefaultPadding *
                        2), // PONENTS THE FILES FOR NEWS SO THAT WE CAN CHANGE
                FooterWeb(),
              ],
            ),
          )
        ],
      )),
    ));
  }

  _buildStoryPage(Map data, int index) {
    double scale = max(0.8, (1 - (pageOffset - index).abs()) + 0.8);
    return FutureBuilder(
      future: FirebaseStorage.instance
          .ref()
          .child(data['movieSliderImg'])
          .getDownloadURL(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(
              child: CircularProgressIndicator(
            valueColor: AlwaysStoppedAnimation<Color>(kPrimaryColor),
          ));
        }
        return InkWell(
          onTap: () {
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => Preview(movId: data['movieId']),
              ),
            );
          },
          child: Container(
            margin: EdgeInsets.only(right: 1, left: 1),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(20),
              image: DecorationImage(
                fit: BoxFit.fill,
                image: NetworkImage(snapshot.data.toString()),
              ),
            ),
            child: Column(
              children: [
                Spacer(),
                Align(
                  alignment: Alignment.bottomLeft,
                  child: ClipRect(
                    child: BackdropFilter(
                      filter: ImageFilter.blur(sigmaX: 7, sigmaY: 1),
                      child: Container(
                        //decoration : BoxDecoration(
                        //borderRadius: BorderRadius.only(
                        //bottomLeft: Radius.circular(20),
                        //),
                        //),
                        color: kFullBlack.withOpacity(0.3),
                        width: MediaQuery.of(context).size.width,
                        height: 80,
                        child: Row(
                          children: [
                            //Icon(Icons.play_arrow_rounded,color:Colors.white, size: 50)
                            Align(
                              alignment: Alignment.center,
                              child: ClipRect(
                                child: Container(
                                  height: 50.0,
                                  width: 50.0,
                                  color: Colors.transparent,
                                  child: new Container(
                                      decoration: new BoxDecoration(
                                          color: Colors.transparent,
                                          border: Border.all(
                                              color: kPrimaryColor, width: 2),
                                          borderRadius: new BorderRadius.only(
                                            topLeft:
                                                const Radius.circular(25.0),
                                            topRight:
                                                const Radius.circular(25.0),
                                            bottomLeft:
                                                const Radius.circular(25.0),
                                            bottomRight:
                                                const Radius.circular(25.0),
                                          )),
                                      child: new Center(
                                          child: new Icon(
                                              Icons.play_arrow_rounded,
                                              color: kPrimaryColor,
                                              size: 25))),
                                ),
                              ),
                            ),
                            Expanded(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 8.0, right: 8.0, top: 8.0),
                                    child: Text(
                                      data['movieName'],
                                      style: TextStyle(
                                          fontSize: 20,
                                          color: Colors.white,
                                          fontWeight: FontWeight.bold),
                                      maxLines: 2,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        left: 8.0, right: 8.0),
                                    child: Text(
                                      data['movieGenre'].join(", "),
                                      style: TextStyle(
                                          fontSize: 12, color: Colors.white),
                                      maxLines: 1,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
