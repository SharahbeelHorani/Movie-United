import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:fialogs/fialogs.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:movie_united/constants/constants.dart';
import 'package:movie_united/localization/language_constants.dart';
import 'package:top_snackbar_flutter/custom_snack_bar.dart';
import 'package:top_snackbar_flutter/top_snack_bar.dart';

import 'login.dart';

class Register extends StatefulWidget {
  final BuildContext rtx;
  const Register({Key key, this.rtx}) : super(key: key);

  @override
  _RegisterState createState() => _RegisterState();
}

String lname = '';
String fname = '';

class _RegisterState extends State<Register> {
  final _formKeyR = GlobalKey<FormState>();
  signOut() async {
    await FirebaseAuth.instance.signOut();
    setState(() {
      isLogged = false;
      userEmail = '';
    });
  }

  TextEditingController password = TextEditingController();
  TextEditingController fname = TextEditingController();
  TextEditingController lname = TextEditingController();
  TextEditingController confirmpassword = TextEditingController();
  bool isLogged = false;
   String userEmail;
   String displayName;

  bool validateAndSaveR() {
    final formR = _formKeyR.currentState;
    if (formR.validate()) {
      formR.save();
      return true;
    }
    return false;
  }

  void validateAndSubmitR() async {
    List<String> lsts = [];
    Map<String, String> map = {};
    if (validateAndSaveR()) {
      try {
        UserCredential user = await FirebaseAuth.instance
            .createUserWithEmailAndPassword(email: _email, password: _password);
        user.user.updateDisplayName(fname.text);
        FirebaseFirestore.instance
            .collection('ratings')
            .doc(user.user.uid)
            .set({
          "tvList": map,
          "movieList": map,
        });
        FirebaseFirestore.instance
            .collection('watchlist')
            .doc(user.user.uid)
            .set({
          "watchList": lsts,
          "movieList": lsts,
        });
        FirebaseFirestore.instance
            .collection('users')
            .doc(user.user.uid)
            .set({
          "uid": user.user.uid,
          "fname": fname.text,
          "lname": lname.text,
          "email": _email,
          "role": 'user',
        })
            .then((value) => signOut())
            .then((value) => _formKeyR.currentState.reset())
            .then((value) => Navigator.of(context).pop());

        print('Registered User: $user');

        showTopSnackBar(
          context,
          CustomSnackBar.success(
            message: getTranslated(widget.rtx, "account_successfully_registered_Pocees_to_login"),
          ),
        );
      } catch (e) {
        print('error $e');
      }
    }
  }

   String _email;
   String _password;
   String _passwordR;
  String _fname = "default";
  String _lname = "defaulT";
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Material(
        child: Container(
          width: double.infinity,
          color: kFullBlack,
          child: SafeArea(
            child: Column(
              children: [
                Container(
                  constraints: BoxConstraints(maxWidth: kMaxWidth),
                  child: Container(
                    height: MediaQuery.of(context).size.height,
                    width: MediaQuery.of(context).size.width,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(5.0),
                      color: kDarkBlackColor,
                      boxShadow: [
                        BoxShadow(
                          color: kPrimaryColor,
                          offset: Offset(0.0, 0.0), //(x,y)
                          blurRadius: 20.0,
                        ),
                      ],
                    ),
                    child: Form(
                      key: _formKeyR,
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Spacer(),
                              Padding(
                                padding: const EdgeInsets.all(18.0),
                                child: InkWell(
                                  onTap: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Icon(
                                    Icons.cancel,
                                    color: Colors.white,
                                    size: 30,
                                  ),
                                ),
                              )
                            ],
                          ),
                          Padding(
                            padding: const EdgeInsets.all(18.0),
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5.0),
                                color: Colors.white,
                                boxShadow: [
                                  BoxShadow(
                                    color: kPrimaryColor,
                                    offset: Offset(0.0, 0.0), //(x,y)
                                    blurRadius: 20.0,
                                  ),
                                ],
                              ),
                              height: MediaQuery.of(context).size.height / 1.2,
                              width: 400,
                              child: ListView(
                                children: [
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 16),
                                  ),
                                  Text(
                                    "Movie United",
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: kPrimaryColor,
                                        fontSize: 25,
                                        fontWeight: FontWeight.w900),
                                  ),
                                  divider(height: 15),
                                  Padding(
                                    padding:
                                    EdgeInsets.symmetric(horizontal: 80),
                                    child: Text(
                                      getTranslated(widget.rtx, "create_account"),
                                      textAlign: TextAlign.center,
                                      style: TextStyle(
                                        color: kPrimaryColor,
                                        fontSize: 22,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 8),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 8),
                                    child: TextFormField(
                                      controller: fname,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        filled: true,
                                        fillColor: Colors.white,
                                        hintText: getTranslated(widget.rtx, "first_name"),
                                      ),
                                      validator: (value) => value.isEmpty
                                          ? getTranslated(widget.rtx, "please_enter_your_first_name")
                                          : null,
                                      onSaved: (value) => _fname = value,
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 8),
                                    child: TextFormField(
                                      controller: lname,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        filled: true,
                                        fillColor: Colors.white,
                                        hintText: getTranslated(widget.rtx, "last_name"),
                                      ),
                                      validator: (value) => value.isEmpty
                                          ? getTranslated(widget.rtx, "please_enter_your_last_name")
                                          : null,
                                      onSaved: (value) => _lname = value,
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 16),
                                    child: TextFormField(
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        filled: true,
                                        fillColor: Colors.white,
                                        hintText: getTranslated(widget.rtx, "email"),
                                      ),
                                      validator: (value) => value.isEmpty
                                          ? getTranslated(widget.rtx, "please_enter_valid_email_address")
                                          : null,
                                      onSaved: (value) => _email = value,
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 16),
                                    child: TextFormField(
                                      // ignore: deprecated_member_use
                                      controller: password,
                                      obscureText: true,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        filled: true,
                                        fillColor: Colors.white,
                                        hintText: getTranslated(widget.rtx, "password"),
                                      ),
                                      validator: (value) => value.isEmpty
                                          ? getTranslated(widget.rtx, "please_enter_your_password")
                                          : null,
                                      onSaved: (value) => _password = value,
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.symmetric(
                                        horizontal: 8, vertical: 16),
                                    child: TextFormField(
                                      // ignore: deprecated_member_use
                                      controller: confirmpassword,
                                      obscureText: true,
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(),
                                        filled: true,
                                        fillColor: Colors.white,
                                        hintText: getTranslated(widget.rtx, "re_enter_password"),
                                      ),
                                      validator: (value) {
                                        if (value.isEmpty) {
                                          return getTranslated(widget.rtx, "please_re_enter_password");
                                        }
                                        if (password.text !=
                                            confirmpassword.text) {
                                          return getTranslated(widget.rtx, "Password_does_not_match");
                                        }
                                      },
                                      onSaved: (value) => _passwordR = value,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        top: 30.0, left: 20, right: 20),
                                    child: ElevatedButton(
                                      child: Text(getTranslated(widget.rtx, "sign_up")),
                                      style: ElevatedButton.styleFrom(
                                        primary: kPrimaryColor,
                                      ),
                                      onPressed: validateAndSubmitR,
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(
                                        top: 30.0, left: 20, right: 20),
                                    child: FlatButton(
                                      child: Text(getTranslated(widget.rtx, "have_account_login")),
                                      onPressed: () {
                                        Navigator.of(context).pop();
                                        Navigator.push(
                                          context,
                                          MaterialPageRoute(
                                              builder: (context) => Login(bcx: widget.rtx,)),
                                        );
                                      },
                                    ),
                                  )
                                ],
                              ),
                            ),
                          ),
                          Spacer()
                        ],
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
